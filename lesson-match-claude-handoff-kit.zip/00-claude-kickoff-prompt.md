---
tags: [project, lesson-match, handoff, prompt, claude]
updated: 2026-11-25
---

# lesson-match Claude Code 引き継ぎ実行用プロンプト

Claude Code を起動する場所に応じて、下の「パターン A」または「パターン B」のコードブロックをそのままコピーして貼り付ける。

## 同梱ファイル一覧（ZIP 展開時）

| パス | 役割 |
|---|---|
| `00-claude-kickoff-prompt.md` | 本ファイル（最初に Claude Code へ貼る実行プロンプト） |
| `claude-handoff.md` | 技術・セキュリティ不変条件、i18n 除外パス、状態遷移表、日次 4 処理の厳密な境界式 |
| `spec-draft.md` | 全体仕様書ドラフト全 11 章（画面遷移図・シーケンス図・全テーブル定義・ER 図・MVP 6 機能の素案） |
| `decisions.md` | これまでの対話で決めた全設計判断の経緯・比較選択肢・採用理由（ADR 形式） |
| `_overview.md` | プロジェクト概要・公開先・KGI / KPI 定義 |
| `log-2026-11-25.md` | 仕様策定セッションの作業ログ |
| `gemini-spec-prompt.md` | 仕様策定に使ったプロンプト原本（改善反映済み） |
| `reference-templates/` | 機能別 handoff 用の雛形（`spec.md`, `tasks.md`, `impl-log.md`, `review.md`, `retro.md`） |
| `reference-shared/` | 共用インフラ・開発フロー規約の参照コピー（`dev-workflow.md`, `docker.md`, `cloudflare.md`, `monitoring.md`, `backup-policy.md`, `analysis-policy.md`） |

## パターン A：司令塔 Vault（`D:\マイドライブ\Obsidian\main`）の Claude Code（Opus 5.5）で始める場合

この PC の Obsidian Vault を開いた Opus 5.5 セッションにそのまま貼るプロンプトである。

```text
作業再開 lesson-match

Gemini との対話で全体仕様・日英バイリンガル対応・改正個人情報保護法対応・運用エッジケースまで詰め終えました。
まず以下のファイルを順番に読んで、全体像と不変条件を完全に把握してください（コードやファイルの変更はまだしないでください）。

1. projects/lesson-match/_overview.md
2. projects/lesson-match/decisions.md
3. projects/lesson-match/handoff/claude-handoff.md
4. projects/lesson-match/handoff/spec-draft.md
5. shared/dev-workflow.md および .claude/skills/stage-start/SKILL.md

読み終えたら、以下を順番に進めてください。

ステップ 1：着手前の未決 2 項目の確認
- ① サービス表示名（日本語名・英語表記。仮置き定数で先に進めるかも含め確認）
- ② Git リモート先（GitHub `https://github.com/om10cg7/lesson-match` にするか Azure DevOps にするか）と、PR 運用（PR を出すか、PR を出さない fast-forward push 運用にするか）
この 2 点を私に質問して回答を待ってください。

ステップ 2（私の回答後）：リポジトリ初期化と実機照合・`設計開始 01-foundation`
- `G:\onedrive\admin\OneDrive - イージーカンパニー\git\lesson-match` を初期化し、`.gitignore` に `.claude/worktrees` と `.env` 系（`.env.example` を除く）を必ず入れること。
- 実機で `Get-NetTCPConnection -State Listen` と `docker ps -a` を実行し、確認用ポート候補 `127.0.0.1:8097`・コンテナ名 `lesson-match-web`・DB 名 `lesson_match` の非衝突を確かめ、コマンドと日付を記録すること。
- `stage-start` skill に従い、`projects/lesson-match/handoff/01-foundation/` に `spec.md` と `tasks.md` を作成すること。
  ※ 重要：実装役（Sonnet サブエージェント）と独立検証役（Opus サブエージェント）には `spec-draft.md` も `claude-handoff.md` も渡されません。`claude-handoff.md` に書かれた不変条件（i18n ミドルウェア除外パス、Prisma 全 MVP テーブル定義、UTC 保存と JST 表記、`CF-Connecting-IP`、DB 切断時 503、改正個法・著作権準拠の日英規約／プラポリ要件、単体テスト用の純粋関数名）を省略せず `01-foundation/spec.md` に自己完結で転記し、`status: ready` にして私の確認を待ってください。
```

## パターン B：ZIP を展開した単独フォルダや別環境の Claude Code で始める場合

Vault の外（新規リポジトリ直下やクラウド版 Claude Code など）にこの ZIP を展開して渡す場合のプロンプトである。

```text
あなたはこのプロジェクト（lesson-match：楽器レッスンの日英バイリンガル対応マッチングサイト）の設計・進行を担う司令塔アーキテクトです。
カレントディレクトリ（または `handoff-kit/` 配下）にある引き継ぎ資料一式を、以下の順番ですべて読んで把握してください（まだ実装は始めないでください）。

1. `_overview.md`
2. `decisions.md`（なぜその設計を選んだかの ADR 記録）
3. `claude-handoff.md`（全機能で守る技術・セキュリティ・改正個人情報保護法の不変条件、状態遷移表、日次バッチの厳密境界式）
4. `spec-draft.md`（全 11 章の全体仕様・MariaDB 全テーブル定義・MVP 6 機能の素案）
5. `reference-shared/dev-workflow.md` および `reference-templates/` 配下の各テンプレート

# 厳守する進め方
- MVP は以下の依存順で 1 機能ずつ進め、複数機能を一度に実装しないこと。
  `01-foundation` → `02-auth-account` → `03-teacher-profile-admin` → `04-public-search-seo` → `05-booking-chat` → `06-notification-ops`
- 各機能は必ず次の工程順を守ること。
  1. 設計：`reference-templates/spec.md` と `tasks.md` の形式で `handoff/<機能名>/spec.md`・`tasks.md` を自己完結で作成し、私の承認（チェックポイント）を待つ。
  2. 実装：私の承認後、1 タスク＝1 コミット目安で実装し、`impl-log.md` に記録する。仕様の曖昧さがあれば勝手に決めず `impl-log.md` の「仕様の疑問」に挙げて解消する。
  3. 独立検証：実装の会話経緯を持たない独立サブエージェントを起動し、`spec.md` の受け入れ条件（AC）と実際のコード・テスト実行結果だけを見て `review.md` に合否判定を書かせる。
  4. 振り返り：`retro.md` を記録してから次の機能へ進む。
- API キー・パスワード等の秘密情報は `.env`（Git 管理外）のみに置き、コード・ログ・ドキュメントに絶対に出さないこと。

まずは資料を読み終えた報告とともに、着手前に決める残り 2 項目（① 日英サービス表示名、② Git リモート先と PR 運用の有無）を私に確認してください。回答後に `01-foundation` の `spec.md` と `tasks.md` の作成へ進んでください。
```
