---
tags: [project, lesson-match, spec-draft]
updated: 2026-11-25
---

# lesson-match 仕様書ドラフト（日英バイリンガル対応）

[[projects/lesson-match/handoff/gemini-spec-prompt|仕様策定プロンプト]] に沿って対話で固めた、楽器レッスンのマッチングサイト（仮称 `lesson-match`）の全体仕様書ドラフトである。
各設計判断の背景・比較した選択肢・採用理由は [[projects/lesson-match/decisions|decisions.md]] に ADR 形式で記録している。
次工程では、本ドラフトの「9. 機能ごとの `spec.md` の素案」「10. `tasks.md` の素案」をもとに、機能単位で「設計開始 `<機能名>`」を実行して正式な受け渡しファイルを作る。

---

## 1. サービス概要（3 行）

1. **目的・対象**：大人の趣味・初心者（在日外国人や英語話者を含む）を中心に、ピアノ・ギター・ボイトレなどの主要楽器を「習いたい生徒」と「教えたい個人講師（プロ・音大生・指導経験のあるアマチュア）」を全国（オンライン＋対面、**日本語・英語の 2 言語対応**）でつなぐ個人開発のマッチングサイトである。
2. **生徒への価値**：大手音楽教室よりも柔軟な料金・ジャンル・時間帯・使用言語（日本語／英語）で相性の良い先生を動画やプロフィールから探せ、体験レッスンから気軽に始められる。
3. **先生への価値**：初期費用・成約手数料 0 円（MVP 期間）で日英対応の紹介ページ（SEO 対応）を持て、カレンダー管理の手間なく希望日リクエストとチャットだけで生徒を受け入れられる。

---

## 2. MVP の機能一覧と、後回し（Phase 2 以降）にする機能一覧

### MVP に含める機能（初期リリース）
- **日英バイリンガル基盤（`/ja`, `/en`）**
  - `next-intl` による URL パスプレフィックス（`/ja/...`, `/en/...`）での画面 UI・固定文言・利用規約等の日英切り替え（ヘッダーに `JP / EN` スイッチャー常設）
  - 先生の対応言語フラグ（日本語レッスン可／英語レッスン可）と一覧での「英語レッスン可（English OK）」絞り込み
  - 先生プロフィール・レッスンメニューの英語入力欄（任意。未入力時は日本語テキストを表示し「Japanese」バッジを添えてフォールバック）
  - ユーザーの通知言語設定（`preferred_locale`: `ja` / `en`）に応じた日英メール送信
- **認証・アカウント管理・ボット対策**
  - メールアドレス＋パスワード（Argon2id ハッシュ＋メール認証）および Google OAuth ログイン（確認済みメール `email_verified_at IS NOT NULL` のみ自動アカウント紐付けを許可）
  - 公開フォーム（新規登録・PW 再設定・通報等）への **Cloudflare Turnstile**（無料ボット対策）および `CF-Connecting-IP` 基準のレート制限（Resend の 1 日 100 通無料枠の枯渇防止）
  - 登録時のロール選択（`student` / `teacher` 固定、1 アカウント 1 ロール）および利用規約・プライバシーポリシー明示同意チェック（同意日時・ポリシー版数を DB に証跡保存）
  - パスワード再設定、退会処理（日英の表示名を含む個人情報を匿名化し、R2 上のアバター画像を削除し、予約・チャット履歴は論理保持）
- **先生プロフィール・メニュー管理**
  - 基本情報（日英表示名、プロフィール画像［Cloudflare R2・変更時は旧画像を自動削除］、指導楽器［複数可・マスタで日英名保持］、対応言語［日本語／英語］、対応レベル、ジャンル、日英の経歴・自己紹介、YouTube 紹介動画 URL 埋め込み）
  - レッスン形態（オンライン可否、対面エリア［都道府県マスタ日英対応＋市区町村・最寄り駅目安の日英テキスト］、対応可能な曜日・時間帯の目安、キャンセル規定［定型 3 パターン・日英自動翻訳表示］）
  - レッスンメニュー登録（「体験レッスン / Trial Lesson」「単発レッスン / Single Lesson」の 2 種別、時間・税込円料金・日英補足説明、支払い方法の案内テキスト）
  - 審査申請ステータス管理（`draft` → `pending_review` → `approved` / `rejected`、公開/一時休止の切り替え）
- **生徒プロフィール管理**
  - 表示名、通知言語（`ja` / `en`）、習いたい楽器、現在のレベル、目的、希望の曜日・時間帯、未成年フラグ（保護者代理または同意確認）
- **公開ページ・検索・SEO**
  - トップページ、先生募集 LP（インボイス未登録の個人・音大生でも登録可能である旨の FAQ 付き）
  - 先生一覧・絞り込み検索（楽器、都道府県、オンライン可否、**英語レッスン可否**、体験レッスン料金上限、対応曜日）
  - 先生詳細ページ（`/[locale]/teachers/[slug]`、SSR、動的 OGP、`hreflang`（`ja`, `en`, `x-default`）、JSON-LD 構造化データ、YouTube 埋め込み）
  - 日英両 URL を含む `sitemap.xml`、`robots.txt`、日英の利用規約（楽譜・音源等の著作物無断複製禁止を含む）・プライバシーポリシー・運営者表記
- **リクエスト予約・チャット**
  - 体験／単発レッスンの申し込み（メニュー選択、受講形式［オンライン/対面］、第 1〜第 3 希望日時［`JST (UTC+9)` 明記］、初回メッセージ、未成年の場合の保護者同意チェック）
  - 1 対 1 チャット（テキストのみ・ファイル添付不可・1 通 2,000 文字上限、アクティブタブ表示中のみ 30 秒間隔で軽量ポーリング）
  - 予約ステータス管理（`requested`［申込中］→ `confirmed`［日時確定］→ `completed`［完了：手動または終了 24 時間後に自動遷移］／ `cancelled`［キャンセル］／ `declined`［辞退］／ `expired`［申込から 7 日放置または全希望日時超過で自動期限切れ］）
  - 確定時のみ開示する情報枠（オンライン通話 URL［Zoom/Meet 等］または対面の詳細場所・住所メモ）
- **通知・定期保守ジョブ（Resend 送信 × Cloudflare Email Routing 受信）**
  - 送信用サブドメイン（`noreply@mail.lesson.ana8labo.com`）による Resend メール送信と、Cloudflare Email Routing による窓口（`support@lesson.ana8labo.com`）の既存メール転送
  - 即時メール通知（受信者の `preferred_locale` に合わせて日英出し分け：メール認証、予約申込、予約確定・辞退・キャンセル、チャット新着［15 分間連投抑止］、先生審査結果）
  - 定期ジョブ（毎日 08:00 JST 実行＋Healthchecks.io へ ping）：① 前日リマインドメール送信、② 7 日放置または希望日超過の `requested` 予約の自動 `expired` 化と通知、③ 終了 24 時間経過した `confirmed` 予約の自動 `completed` 化、④ 終了系ステータスから 1 年（365 日）経過した予約の詳細場所・支払案内・チャット本文の自動マスク（個情法第 22 条対応）
- **安全・管理画面（`/admin`）・監査ログ**
  - Cloudflare Access ＋ アプリ側管理者ロールの二重保護
  - 先生の公開審査（日英プロフィール確認・承認／差し戻しコメント送信）
  - 通報フォーム（日英 UI で生徒・先生双方が運営へ通報）と管理画面での通報一覧確認
  - アカウント強制停止・先生ページの非公開化、および全管理操作の監査ログ記録（`admin_audit_logs`）

### 後回し（Phase 2 以降）にする機能
- **決済・収益化機能**：Stripe（Checkout / Connect）によるサイト内事前決済、プラットフォーム手数料徴収、先生の月額掲載プラン、インボイス登録番号の適格表示・領収書 PDF 発行
- **多言語・国際化の高度化**：海外在住者向けのユーザー別タイムゾーン自動変換表示、プロフィールやチャットの AI 自動翻訳ボタン、3 言語目（中国語・韓国語等）の追加
- **評判・継続機能**：受講完了後の星評価・レビュー投稿、先生のお気に入り保存、月謝コース・回数券メニュー
- **高度なスケジュール・連絡機能**：空き枠カレンダー即時予約（Google カレンダー連携）、LINE 通知連携、サイト内ビデオ通話組み込み
- **高度な安全・アカウント機能**：ユーザー間の個別ブロック機能、1 アカウントでの先生・生徒ロール兼任切り替え、本人確認書類（eKYC）連携

---

## 3. 画面一覧と画面遷移図

### 画面一覧（`[locale]` は `ja` または `en`）

| 区分 | パス（URL 設計） | 画面名 | 公開範囲 / インデックス |
|---|---|---|---|
| 公開 | `/[locale]` | トップページ（`/` アクセス時は言語判定で `/ja` または `/en` へ誘導） | 公開 / `index` (`hreflang` 付) |
| 公開 | `/[locale]/teachers` | 先生検索・一覧ページ（楽器・地域・オンライン・英語可・料金・曜日） | 公開 / `index` (`hreflang` 付) |
| 公開 | `/[locale]/teachers/[slug]` | 先生詳細ページ（日英プロフィール・動画・メニュー・申込導線） | 公開（承認済みのみ） / `index` (`hreflang` 付) |
| 公開 | `/[locale]/for-teachers` | 先生募集ランディングページ（日本人・英語話者講師双方の受け皿） | 公開 / `index` (`hreflang` 付) |
| 公開 | `/[locale]/terms`, `/[locale]/privacy`, `/[locale]/legal` | 利用規約・プライバシーポリシー・運営者表記（日英） | 公開 / `index` (`hreflang` 付) |
| 認証 | `/[locale]/login`, `/[locale]/register` | ログイン・新規登録（ロール選択、現在の `locale` を初期通知言語に設定） | 公開 / `noindex` |
| 認証 | `/[locale]/verify-email`, `/[locale]/forgot-password`, `/[locale]/reset-password` | メール確認・パスワード再設定 | 公開 / `noindex` |
| 生徒 | `/[locale]/dashboard/bookings` | 生徒マイページ：予約・相談一覧 | 生徒のみ / `noindex` |
| 生徒 | `/[locale]/dashboard/bookings/[id]` | 予約詳細・1 対 1 チャット・確定情報確認 | 当事者のみ / `noindex` |
| 生徒 | `/[locale]/teachers/[slug]/book` | レッスン申し込みフォーム（第 1〜3 希望日時 `JST` 入力） | 生徒のみ / `noindex` |
| 生徒 | `/[locale]/dashboard/profile` | 生徒プロフィール・通知言語編集・退会 | 生徒のみ / `noindex` |
| 先生 | `/[locale]/teacher/dashboard` | 先生マイページ：受信リクエスト・確定予定一覧 | 先生のみ / `noindex` |
| 先生 | `/[locale]/teacher/bookings/[id]` | 予約応対・日時確定操作・1 対 1 チャット | 当事者のみ / `noindex` |
| 先生 | `/[locale]/teacher/profile` | 先生プロフィール（日英タブ）・対応言語・メニュー編集・審査申請 | 先生のみ / `noindex` |
| 共通 | `/[locale]/reports/new` | 通報フォーム（対象ユーザー/予約指定） | ログイン必須 / `noindex` |
| 管理 | `/admin`, `/admin/teachers`, `/admin/users`, `/admin/reports` | 管理ダッシュボード・先生審査・ユーザー停止・通報対応（運営専用のため日本語 UI 固定） | 管理者＋CF Access / `noindex` |

> **SEO 観点のページ構成**：
> - `/ja/teachers/[slug]` は `<h1>[表示名]の[楽器名]レッスン（[都道府県/オンライン]）</h1>`、`/en/teachers/[slug]` は `<h1>[Instrument] Lessons with [Display Name EN] ([Prefecture EN / Online])</h1>` を出力する。
> - 両ページ間で `<link rel="alternate" hreflang="ja" ...>` / `hreflang="en"` / `hreflang="x-default"` を相互出力し、「piano lessons in Tokyo English」「ギター 個人レッスン オンライン」など日英双方のロングテール検索流入を狙う。

### 画面遷移図（Mermaid）

```mermaid
flowchart TD
    Top["/[locale] トップページ (JP/EN 切替可)"] --> Search["/[locale]/teachers 先生検索 (英語可フィルタ付)"]
    Top --> ForTeachers["/[locale]/for-teachers 先生募集LP"]
    Search --> Detail["/[locale]/teachers/[slug] 先生詳細"]
    ForTeachers --> Register["/[locale]/register 新規登録 (先生/生徒)"]
    Detail --> BookForm["/[locale]/teachers/[slug]/book リクエスト予約申込"]
    BookForm --> Login["/[locale]/login ログイン"]
    Login --> BookForm

    Register --> StudentProf["/[locale]/dashboard/profile 生徒プロフィール"]
    Register --> TeacherProf["/[locale]/teacher/profile 先生プロフィール (日英入力)・審査申請"]

    BookForm --> StudentBooking["/[locale]/dashboard/bookings/[id] 予約詳細・チャット (生徒)"]
    TeacherProf --> AdminReview["/admin/teachers 先生審査 (管理者)"]
    AdminReview -->|承認| Detail

    StudentBooking <-->|チャット・日時確定| TeacherBooking["/[locale]/teacher/bookings/[id] 予約応対・チャット (先生)"]
    StudentBooking --> Report["/[locale]/reports/new 通報フォーム"]
    TeacherBooking --> Report
    Report --> AdminReport["/admin/reports 通報対応・利用停止"]
```

---

## 4. 予約から受講、支払い、レビューまでの流れ（シーケンス図）

生徒（例：英語 UI 利用）と先生（例：日本語 UI 利用）の間でも通知言語が自動で出し分けられる流れと、Phase 2 拡張ポイントを示す。

```mermaid
sequenceDiagram
    actor S as 生徒 (ja または en)
    participant W as lesson-match (Next.js / MariaDB)
    participant M as Resend (日英メール出し分け)
    actor T as 先生 (ja または en)

    S->>W: メニュー選択・第1〜3希望日時(JST)を送る (requested)
    W->>M: 先生の preferred_locale で申込通知メール送信
    M-->>T: 新着リクエスト通知 (日 or 英)
    T->>W: チャットで日程・場所/オンライン環境をすり合わせ
    W->>M: 生徒の preferred_locale で新着メッセージ通知
    T->>W: 確定日時・通話URL(または詳細住所)・支払案内を登録して確定 (confirmed)
    W->>M: 生徒の preferred_locale で予約確定メール送信
    Note over S,T: 【MVP】先生の案内に従い当事者間で支払い (振込・PayPay・当日現金等)<br/>【Phase 2拡張】確定時または申込時に Stripe Checkout (日英UI対応) で決済

    W->>M: 前日 08:00 JST バッチで双方の言語でリマインド送信 (+ Healthchecks ping)
    S->>T: レッスン受講 (オンライン通話 または 対面スタジオ/教室)
    T->>W: レッスン完了ボタンを押す (または終了24時間後に自動 completed)
    Note over S,W: 【Phase 2拡張】completed 確定で売上計上・生徒の言語でレビュー依頼メール送信
```

---

## 5. データモデル（MariaDB `utf8mb4` 前提）

### 主要テーブル一覧

#### 1) `users`（認証・共通アカウント）
| カラム名 | 型 | NULL | 説明 |
|---|---|---|---|
| `id` | `BIGINT UNSIGNED PK AUTO_INCREMENT` | NO | ユーザー ID |
| `public_id` | `VARCHAR(36) UNIQUE` | NO | 外部露出用 UUID/CUID |
| `email` | `VARCHAR(255) UNIQUE` | NO | メールアドレス（退会時は `deleted_<id>@invalid.local` に置換） |
| `email_verified_at` | `DATETIME` | YES | メール確認日時 |
| `password_hash` | `VARCHAR(255)` | YES | Argon2id ハッシュ（Google のみの場合は NULL） |
| `google_sub` | `VARCHAR(255) UNIQUE` | YES | Google OAuth の `sub` 識別子 |
| `role` | `ENUM('student','teacher','admin')` | NO | 登録時に決定・固定 |
| `preferred_locale` | `ENUM('ja','en')` | NO | 通知メール等の優先言語（登録時の画面ロケールで初期化） |
| `terms_consented_at` | `DATETIME` | NO | 利用規約への同意日時（第 27 条等の同意証跡） |
| `privacy_consented_at` | `DATETIME` | NO | プライバシーポリシーへの同意日時 |
| `consented_policy_version` | `VARCHAR(20)` | NO | 同意した規約・プラポリ版数（例：`2026-11`） |
| `status` | `ENUM('active','suspended','withdrawn')` | NO | 利用状態（停止・退会） |
| `withdrawn_at` | `DATETIME` | YES | 退会日時 |
| `created_at` / `updated_at` | `DATETIME` | NO | 作成・更新日時 |

#### 2) `teacher_profiles`（先生プロフィール・日英対応）
| カラム名 | 型 | NULL | 説明 |
|---|---|---|---|
| `user_id` | `BIGINT UNSIGNED PK FK(users.id)` | NO | 1 対 1 主キー |
| `slug` | `VARCHAR(80) UNIQUE` | NO | 公開 URL 用スラッグ（英数字ハイフン） |
| `display_name` | `VARCHAR(80)` | NO | 日本語表示名（退会時は「退会済み講師」に匿名化） |
| `display_name_en` | `VARCHAR(80)` | YES | 英語表示名（任意。未入力時は `display_name`、退会時は `Deleted Teacher`） |
| `avatar_key` | `VARCHAR(255)` | YES | Cloudflare R2 オブジェクトキー |
| `speaks_japanese` | `BOOLEAN` | NO | 日本語でのレッスン対応可否 |
| `speaks_english` | `BOOLEAN` | NO | 英語でのレッスン対応可否（検索フィルタ用インデックス） |
| `headline` | `VARCHAR(120)` | NO | 肩書き・キャッチコピー（主言語） |
| `headline_en` | `VARCHAR(160)` | YES | 英語キャッチコピー（任意） |
| `bio` | `TEXT` | NO | 経歴・自己紹介・指導方針（主言語） |
| `bio_en` | `TEXT` | YES | 英語での経歴・自己紹介（任意） |
| `youtube_url` | `VARCHAR(255)` | YES | 紹介動画の YouTube URL |
| `is_online_available` | `BOOLEAN` | NO | オンライン対応可否 |
| `is_inperson_available` | `BOOLEAN` | NO | 対面対応可否 |
| `prefecture_code` | `TINYINT UNSIGNED` | YES | 主な活動都道府県コード（1〜47、コードから日英県名へ変換） |
| `area_text` | `VARCHAR(120)` | YES | 公開エリア目安（例：「新宿駅・渋谷駅周辺のスタジオ」） |
| `area_text_en` | `VARCHAR(160)` | YES | 英語公開エリア目安（例：`Studios near Shinjuku / Shibuya Sta.`） |
| `private_location_note` | `TEXT` | YES | 予約確定後に開示すべき教室詳細案内（テンプレート用） |
| `available_schedule_note` | `VARCHAR(255)` | NO | 対応可能な曜日・時間帯の目安テキスト |
| `available_schedule_note_en` | `VARCHAR(255)` | YES | 英語での対応時間帯テキスト（任意） |
| `available_days_mask` | `TINYINT UNSIGNED` | NO | 曜日絞り込み用ビットマスク（月〜日、UI 側で日英自動表示） |
| `cancellation_policy_type` | `ENUM('flexible','standard','strict')` | NO | 定型キャンセル規定（コード値から日英どちらでも自動表示） |
| `payment_method_note` | `VARCHAR(255)` | NO | MVP での支払い受け取り方法の説明 |
| `payment_method_note_en` | `VARCHAR(255)` | YES | 英語での支払い受け取り方法の説明（任意） |
| `review_status` | `ENUM('draft','pending_review','approved','rejected')` | NO | 運営審査ステータス |
| `review_comment` | `TEXT` | YES | 差し戻し時の運営コメント |
| `is_public` | `BOOLEAN` | NO | 先生自身の公開/募集休止トグル（`approved` かつ `TRUE` のみ公開） |
| `created_at` / `updated_at` | `DATETIME` | NO | 作成・更新日時 |

#### 3) `instruments` / `teacher_instruments`（楽器マスタ・指導楽器中間テーブル）
- `instruments`: `id` (PK), `code` (`piano`, `acoustic-guitar`, `electric-guitar`, `voice`, `violin`, `drums`, `bass`, `saxophone`, `flute`, `dtm` 等), `name_ja` (`VARCHAR(60)`), **`name_en` (`VARCHAR(60)`)**, `sort_order`
- `teacher_instruments`: `teacher_user_id` (FK), `instrument_id` (FK), `min_level` (`beginner`/`intermediate`/`advanced`), `max_level` — 複合 PK `(teacher_user_id, instrument_id)`

#### 4) `lesson_menus`（先生のレッスンメニュー・日英対応）
| カラム名 | 型 | NULL | 説明 |
|---|---|---|---|
| `id` | `BIGINT UNSIGNED PK AUTO_INCREMENT` | NO | メニュー ID |
| `teacher_user_id` | `BIGINT UNSIGNED FK(teacher_profiles.user_id)` | NO | 先生 ID |
| `menu_type` | `ENUM('trial','single')` | NO | 体験レッスン / 単発レッスン |
| `title` | `VARCHAR(100)` | NO | メニュー名（日本語または主言語） |
| `title_en` | `VARCHAR(120)` | YES | 英語メニュー名（任意。未入力時は `title` にフォールバック） |
| `duration_minutes` | `SMALLINT UNSIGNED` | NO | レッスン時間（分） |
| `price_yen` | `INT UNSIGNED` | NO | 税込料金（円。無料体験は `0`、英語 UI でも `¥3,000 (tax incl.)` 表記） |
| `delivery_mode` | `ENUM('online','inperson','both')` | NO | 受講形式 |
| `description` | `TEXT` | YES | 補足説明（スタジオ代別途の有無など） |
| `description_en` | `TEXT` | YES | 英語補足説明（任意） |
| `is_active` | `BOOLEAN` | NO | 有効フラグ |

#### 5) `student_profiles`（生徒プロフィール）
| カラム名 | 型 | NULL | 説明 |
|---|---|---|---|
| `user_id` | `BIGINT UNSIGNED PK FK(users.id)` | NO | 1 対 1 主キー |
| `display_name` | `VARCHAR(80)` | NO | 表示名（退会時は「退会済みユーザー / Deleted User」に匿名化） |
| `is_minor` | `BOOLEAN` | NO | 未成年（18 歳未満）の受講か |
| `guardian_consent_at` | `DATETIME` | YES | 保護者同意または保護者代理登録の確認日時 |
| `target_instruments_text` | `VARCHAR(120)` | YES | 習いたい楽器 |
| `experience_level` | `ENUM('unexperienced','beginner','intermediate','advanced')` | NO | 経験レベル |
| `goal_note` | `TEXT` | YES | 目的・弾きたい曲・希望時間帯など |
| `created_at` / `updated_at` | `DATETIME` | NO | 作成・更新日時 |

#### 6) `bookings`（リクエスト予約・取引記録）
| カラム名 | 型 | NULL | 説明 |
|---|---|---|---|
| `id` | `BIGINT UNSIGNED PK AUTO_INCREMENT` | NO | 予約 ID |
| `public_id` | `VARCHAR(36) UNIQUE` | NO | URL 用識別子 |
| `student_user_id` | `BIGINT UNSIGNED FK(users.id)` | NO | 生徒 ID |
| `teacher_user_id` | `BIGINT UNSIGNED FK(users.id)` | NO | 先生 ID |
| `lesson_menu_id` | `BIGINT UNSIGNED FK(lesson_menus.id)` | NO | 申込メニュー ID |
| `menu_title_snapshot` | `VARCHAR(100)` | NO | 申込時点の日本語メニュー名スナップショット |
| `menu_title_en_snapshot` | `VARCHAR(120)` | YES | 申込時点の英語メニュー名スナップショット |
| `price_yen_snapshot` | `INT UNSIGNED` | NO | 申込時点の税込料金スナップショット |
| `duration_minutes_snapshot` | `SMALLINT UNSIGNED` | NO | 申込時点の時間（分）スナップショット |
| `delivery_mode` | `ENUM('online','inperson')` | NO | 希望受講形式 |
| `candidate_slot_1` | `DATETIME` | NO | 第 1 希望開始日時（DB は UTC 保存、画面・メールは `JST (UTC+9)` 明記で統一） |
| `candidate_slot_2` | `DATETIME` | YES | 第 2 希望開始日時 |
| `candidate_slot_3` | `DATETIME` | YES | 第 3 希望開始日時 |
| `confirmed_start_at` | `DATETIME` | YES | 確定したレッスン開始日時（リマインド対象インデックス） |
| `confirmed_end_at` | `DATETIME` | YES | 確定したレッスン終了日時 |
| `meeting_url_or_location` | `TEXT` | YES | `confirmed` 以降のみ生徒に開示する通話 URL または対面詳細場所 |
| `payment_instruction` | `TEXT` | YES | 先生からの支払い案内メモ |
| `guardian_consented` | `BOOLEAN` | NO | 申込時の保護者同意確認フラグ |
| `cancellation_policy_snapshot` | `VARCHAR(40)` | NO | 申込時点のキャンセル規定コード（表示時に日英辞書変換） |
| `status` | `ENUM('requested','confirmed','completed','cancelled','declined','expired')` | NO | 予約状態（`expired` は 7 日放置または希望日超過の自動期限切れ） |
| `cancelled_by_role` | `ENUM('student','teacher','admin')` | YES | キャンセル実行者 |
| `cancel_reason` | `VARCHAR(255)` | YES | キャンセル／辞退理由 |
| `reminded_at` | `DATETIME` | YES | 前日リマインドメール送信済み日時（二重送信防止） |
| `pii_purged_at` | `DATETIME` | YES | 終了から 1 年経過後の詳細場所・支払案内・チャット本文の自動マスク実行日時 |
| `created_at` / `updated_at` | `DATETIME` | NO | 作成・更新日時 |

#### 7) `booking_messages` / `reports` / `auth_tokens` / `admin_audit_logs`
- `booking_messages`: `id` (PK), `booking_id` (FK `bookings.id`), `sender_user_id` (FK `users.id`), `body` (`TEXT`), `read_at` (`DATETIME` NULL), `created_at` (`DATETIME`)
- `reports`: `id` (PK), `reporter_user_id` (FK), `target_user_id` (FK), `booking_id` (FK NULL), `category` (`ENUM('nuisance','solicitation','no_show','fraud','other')`), `detail` (`TEXT`), `status` (`ENUM('open','in_progress','resolved')`), `admin_note` (`TEXT` NULL), `created_at`, `updated_at`
- `auth_tokens`: `id` (PK), `user_id` (FK), `token_hash` (`CHAR(64)` SHA-256), `purpose` (`ENUM('verify_email','reset_password')`), `expires_at` (`DATETIME`), `used_at` (`DATETIME` NULL), `created_at`
- `admin_audit_logs`（個情法第 23 条 安全管理措置・操作監査用）: `id` (PK), `admin_user_id` (FK `users.id`), `action` (`VARCHAR(60)`: `approve_teacher`, `reject_teacher`, `suspend_user`, `resolve_report` 等), `target_type` (`VARCHAR(40)`), `target_id` (`BIGINT UNSIGNED`), `metadata_json` (`JSON` NULL: 個人情報を含めない変更概要), `ip_address` (`VARCHAR(45)` NULL), `created_at` (`DATETIME`)

### ER 図（Mermaid）

```mermaid
erDiagram
    users ||--o| teacher_profiles : "has (role=teacher)"
    users ||--o| student_profiles : "has (role=student)"
    users ||--o{ auth_tokens : "issues"
    users ||--o{ admin_audit_logs : "records (role=admin)"
    teacher_profiles ||--o{ teacher_instruments : "teaches"
    instruments ||--o{ teacher_instruments : "categorizes (ja/en)"
    teacher_profiles ||--o{ lesson_menus : "offers (ja/en)"
    users ||--o{ bookings : "books as student"
    users ||--o{ bookings : "receives as teacher"
    lesson_menus ||--o{ bookings : "snapshot from"
    bookings ||--o{ booking_messages : "contains"
    users ||--o{ booking_messages : "sends"
    users ||--o{ reports : "submits / reported"
    bookings |o--o{ reports : "referenced in"
```

---

## 6. 技術スタックと構成図

### 採用技術スタックと共通未決項目への設計案
- **Web / アプリケーション / i18n**：Next.js（App Router / TypeScript、Node.js LTS、standalone ビルド）＋ **`next-intl`**
  - 1 つのコンテナ（`lesson-match-web`）で `/ja`・`/en` の SSR 公開ページ、API Route / Server Actions、管理画面を完結させ、同居 Windows PC のメモリ消費とコンテナ数を抑える。
  - 文言辞書は `messages/ja.json` と `messages/en.json` で型安全に管理し、キー漏れをビルド・単体テストで検知できるようにする。
- **ORM・マイグレーション**：Prisma ORM（MariaDB / MySQL プロバイダ）
  - マイグレーションは `prisma migrate deploy` で管理する。本番稼働時は DDL 権限を持たない `lesson_match_web` / `lesson_match_batch` で動かす。
- **認証・パスワード保存・ボット対策**：Auth.js（NextAuth v5）または同等のセッション管理 ＋ **Cloudflare Turnstile**
  - ログイン手段：① メールアドレス＋パスワード（`@node-rs/argon2` による **Argon2id**）、② Google OAuth 2.0（既存ユーザーの `email_verified_at` が確認済みの場合のみ同一メールアドレスへ自動紐付けし、未確認レコードへの乗っ取り紐付けを防止）。
  - ボット・レート制限：公開フォームに無料の Cloudflare Turnstile を組み込み、Tunnel 越しに付与される `CF-Connecting-IP` ヘッダー（開発環境は `127.0.0.1`）基準で IP レート制限を掛けて Resend 無料枠（1 日 100 通）の枯渇を防ぐ。
- **メール送受信の分離（MX 競合回避）**：
  - 送信：**Resend**（送信用サブドメイン `mail.lesson.ana8labo.com` に SPF / DKIM / Return-Path MX を設定し、`noreply@mail.lesson.ana8labo.com` から送信。月 3,000 通・日 100 通無料枠）。宛先ユーザーの `preferred_locale` に応じて日英件名・本文を出し分ける。
  - 受信：**Cloudflare Email Routing**（`lesson.ana8labo.com` の受信用 MX を設定し、窓口アドレス `support@lesson.ana8labo.com` を運営者の既存メールへ無料転送）。
- **画像・動画の置き場所**：
  - プロフィール画像：**Cloudflare R2**（月 10GB・エグレス無料、最大 2MB、WebP リサイズ・EXIF 除去）。画像差し替え時および退会時には旧 `avatar_key` オブジェクトを R2 から自動削除し、孤立ファイルの蓄積を防ぐ。
  - 紹介動画：**YouTube URL（`youtube-nocookie.com` 埋め込み）**のみ。
- **アプリログ・個人情報保護**：
  - `pino` で JSON 構造化ログを標準出力に出し、Docker `json-file`（`max-size: "10m"`, `max-file: "5"`）でローテーションする。メール・氏名・チャット本文・トークン・住所はマスクする。
- **週次 DB 停止・非機能要件**：
  - 毎週月曜 4:00 の MariaDB ボリューム複製による一時停止中は、日英併記の 503 メンテナンス画面を返し、前日リマインド定期ジョブは月曜 4:00 を避け **毎日 08:00 JST** に実行する。

### インフラ構成図（Mermaid）

```mermaid
flowchart LR
    User["生徒・先生 (/ja または /en)"] -->|HTTPS| CF["Cloudflare Edge (DNS / SSL終端)"]
    Admin["運営者 (岡本)"] -->|HTTPS + ワンタイムPIN| CFAccess["Cloudflare Access (/admin 保護)"]
    CFAccess --> CF

    subgraph HostPC["同居 Windows PC (Docker Desktop)"]
        subgraph SharedNet["Docker Network: sharednet"]
            Tunnel["cloudflare_tunnel-cloudflared-1 (ana8labo-tunnel)"]
            Web["lesson-match-web (Next.js + next-intl :3000)"]
            DB[("dev-mariadb (:3306 / lesson_match)")]
        end
        Cron["タスクスケジューラ または 軽量cron (毎日 08:00 JST リマインド)"]
        Watch["docker_watch.py (5分おき 層1監視)"]
    end

    CF -->|Tunnel| Tunnel
    Tunnel -->|"http://lesson-match-web:3000"| Web
    Web -->|Prisma| DB
    Cron -->|"内部トークン付実行"| Web

    Web -->|画像保存・配信| R2["Cloudflare R2 (プロフィール画像)"]
    Web -->|"メール送信API (ja/en)"| Resend["Resend (通知・リマインド)"]
    Web -->|層2 ping| HC["Healthchecks.io -> Slack #アラート"]
    Watch -->|層1 ping| HC
    Uptime["UptimeRobot (層3 5分おき)"] -->|"GET /api/healthz"| CF
```

---

## 7. 共通事項への載せ方

- **DB 名・ユーザー案**：DB `lesson_match`（`utf8mb4`）。ユーザーは `lesson_match_web`（DML のみ）、`lesson_match_batch`（SELECT/UPDATE）、`lesson_match_migrate`（マイグレーション時 DDL）に分離。日次全 DB ダンプ（毎日 3:00）に含める。
- **Docker・ポート案**：リポジトリ `G:\onedrive\admin\OneDrive - イージーカンパニー\git\lesson-match`、`sharednet` 上のコンテナ名 `lesson-match-web`。ローカル確認用ポートが必要な場合は `127.0.0.1:8097:3000`（実装開始時に空き再確認）。
- **Cloudflare 案**：サブドメイン `lesson.ana8labo.com` → `http://lesson-match-web:3000`。`/admin*` は Cloudflare Access で保護。
- **死活監視案**：
  - ヘルスチェック：`GET /api/healthz`（ロケールプレフィックス無しの API パスとして公開し、DB `SELECT 1` 確認）
  - 層 1：`docker_watch.py`（`docker-host`）
  - 層 2：Healthchecks.io チェック名 **`lesson-match-reminder`**（毎日 08:00 JST 実行、周期 1 日・猶予 2 時間 → Slack `#アラート`）
  - 層 3：UptimeRobot チェック名 **`lesson-match-web`**（`https://lesson.ana8labo.com/api/healthz`、5 分間隔 → メール）
- **GA4・Search Console 指標定義**：
  - 成果指標：① 公開中の先生数（うち英語対応講師数も把握）、② リクエスト予約申込数（`booking_request_submitted`）、③ 予約確定数（`booking_confirmed`）
  - 中間指標：言語別（`/ja`, `/en`）の検索流入セッション数、先生詳細ページ閲覧数、先生募集 LP からの登録遷移率
- **`.env` 項目名一覧（値は書かない）**：
  - `NODE_ENV`, `APP_BASE_URL`, `AUTH_SECRET`, `ADMIN_EMAILS`, `CRON_INTERNAL_TOKEN`
  - `DATABASE_URL`, `DATABASE_MIGRATE_URL`, `DATABASE_BATCH_URL`
  - `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`
  - `NEXT_PUBLIC_TURNSTILE_SITE_KEY`, `TURNSTILE_SECRET_KEY`
  - `RESEND_API_KEY`, `MAIL_FROM_ADDRESS` (`noreply@mail.lesson.ana8labo.com`)
  - `R2_ACCOUNT_ID`, `R2_ACCESS_KEY_ID`, `R2_SECRET_ACCESS_KEY`, `R2_BUCKET_NAME`, `R2_PUBLIC_BASE_URL`
  - `HC_REMINDER_PING_URL`, `NEXT_PUBLIC_GA_MEASUREMENT_ID`

---

## 8. 安全と法務・改正個人情報保護法（個法）対応（日英対応）

1. **個人情報取扱事業者の公表（個情法 第 32 条）**
   - 運営主体は **合同会社Anaheim Eight（英語表記：Anaheim Eight LLC）** とし、`/[locale]/privacy` および `/[locale]/legal` に **法人名・登記上の本店所在地・代表者氏名・問い合わせ／開示等請求窓口メールアドレス（`support@lesson.ana8labo.com`、Cloudflare Email Routing で受信）** を明記して第 32 条の公表義務を正面から充足する。
2. **英語版公開に伴う海外法令（GDPR 等）の域外適用回避・準拠法**
   - 日英の利用規約・プライバシーポリシーに「本サービスは日本国内居住者（在日外国人を含む）を対象としたサービス（円建て `JPY`・日本標準時 `JST` 基準）であり、EEA・英国等の海外居住者を対象とした提供・勧誘を行わない」旨を明記し、GDPR 第 3 条第 2 項のターゲティング該当リスクを回避する。
   - 準拠法は日本法、専属的合意管轄は運営者所在地を管轄する日本の裁判所とし、日本語版を正文（英語版は参考訳）と明記する。
3. **外国にある事業者・外部クラウド利用の公表（個情法 第 23 条・第 28 条・外部送信規律）**
   - `/[locale]/privacy` に以下の外部サービス・所在国（米国等）・送信／保管項目・利用目的・米国の個人情報保護制度概要（個情委公表資料ベース）の一覧表を掲載する（Cookie 同意バナーは置かず、GA4 オプトアウト手段を案内する）：
     - **Cloudflare, Inc.（米国）**：通信中継（Tunnel / CDN）、ボット対策（Turnstile）、メール転送（Email Routing）、管理認証（Access）、プロフィール画像保管（R2）
     - **Resend, Inc.（米国）**：認証・予約・リマインドメール配信
     - **Google LLC（米国）**：Google OAuth 認証、GA4 アクセス解析、YouTube 動画埋め込み（`youtube-nocookie.com`）
     - **Microsoft Corporation（米国／クラウド）**：日次 DB ダンプの保管（OneDrive）
4. **同意証跡の記録（第 27 条）と要配慮個人情報の取得回避（第 20 条第 2 項）**
   - 新規登録時（Google OAuth 初回登録を含む）に利用規約・プライバシーポリシーへの明示同意チェックを必須とし、`users` テーブルに `terms_consented_at`・`privacy_consented_at`・`consented_policy_version` を保存する。
   - プロフィール編集・予約申込・チャット入力欄に「病歴・心身の障がい等の要配慮個人情報は記入しないでください」の注意書きを日英で表示する。
5. **保存期間・データ最小化（第 22 条）と開示等請求対応（第 33 条〜第 35 条）**
   - 予約が終了系ステータス（`completed` / `cancelled` / `declined` / `expired`）になってから **1 年（365 日）経過**したレコードは、日次バッチで `meeting_url_or_location`・`payment_instruction` を `NULL` 化し、`booking_messages.body` を自動マスクして `pii_purged_at` を記録する。
   - 退会時は `display_name`・`display_name_en`・`email`・自己紹介を即時匿名化し、R2 上のアバター画像を削除したうえで、予約スナップショット・チャット枠のみ論理保持する。
   - 保有個人データの開示・訂正・利用停止・削除請求は、マイページでの自己対応に加え、登録メールアドレスからの本人確認によるメール窓口（`support@lesson.ana8labo.com`、電磁的記録提供・手数料無料）で遅滞なく対応する。
6. **技術的・物理的安全管理措置（第 23 条）と漏えい等報告手順（第 26 条）**
   - 管理画面での審査承認・差し戻し・アカウント停止・通報対応はすべて `admin_audit_logs` に `CF-Connecting-IP` とともに追記記録する（アプリ側 DB ユーザーからは削除・更新を行わない）。
   - 本番公開前に、同居 Windows PC の **BitLocker 有効化・OS 自動ロック確認**、および共用 `dev-mariadb` のホスト公開を `0.0.0.0:3306` から `127.0.0.1:3306`（または `sharednet` 内部接続のみ）へ絞れるかの他プロジェクト影響確認を実施する。画像アップロード時は EXIF（GPS 位置情報）を除去する。
   - 運用手順書に、漏えい等インシデント発生時の緊急遮断手順（Tunnel 切り離し・コンテナ停止・鍵失効）および個人情報保護委員会への **速報（発覚後 3〜5 日以内）・確報（30 日／不正アクセス等は 60 日以内）・本人通知手順** を整備する。
7. **先生の公開審査・未成年ルール・対面の安全対策・著作権保護・定型キャンセル規定**
   - 先生の初回公開は管理画面で目視審査し、身分証画像は保持しない。18 歳未満の受講は保護者代理または保護者同意チェックを必須とする。
   - 利用規約の禁止事項に、勧誘・ハラスメントに加えて **「市販楽譜・音源・教則本等の著作物の無断複製・スキャン・データ共有（著作権侵害行為）」** を明記する（チャットへのファイル添付不可仕様とも連動）。
   - 公開ページには都道府県＋大まかなエリア目安のみを出し、詳細住所・通話 URL は `confirmed` 確定後に当事者のみに開示する。
   - キャンセル規定は定型 3 パターン（`flexible`: 24h 前無料 / `standard`: 48h 前無料 / `strict`: 7 日前無料・前日 50%）から選択し、日英自動表示とする。

---

## 9. 機能ごとの `spec.md` の素案（MVP 6 機能）

### 機能 1：`01-foundation`（基盤構築・日英 i18n・DB・ヘルスチェック・個法準拠の日英規約／プラポリ）
- **目的**：Next.js + `next-intl` (`/ja`, `/en`) + Prisma + MariaDB コンテナ構成を立ち上げ、日英切り替え・死活監視・改正個法準拠の日英規約／プラポリページを備えた土台を作る。
- **対象範囲**：
  - やること：Next.js 初期化、`next-intl` 導入（`/ja`, `/en` ルーティング、ヘッダー言語スイッチャー、`messages/ja.json` と `messages/en.json` のキー一致テスト）、Prisma スキーマ初期定義（英語カラム・同意証跡・`pii_purged_at`・`admin_audit_logs` 含む全 MVP テーブル）とマイグレーション、Docker / `sharednet` 設定、`GET /api/healthz`、DB 障害時の日英併記 503 応答、`/[locale]/terms`・`/privacy`・`/legal`（合同会社Anaheim Eight 第 32 条表記、米国クラウド／外部送信一覧表、GA4 オプトアウト、開示等請求窓口、日本国内居住者対象・日本法準拠・日本語正文の明記）。
  - やらないこと：ログイン機能、検索画面、外部 API（Resend / R2）本接続。
- **受け入れ条件**：
  - [ ] AC-1：`prisma migrate deploy` が `lesson_match` DB（utf8mb4）に対して完了し、`admin_audit_logs` を含む全 MVP テーブルが作成される → 確認方法：コンテナ内コマンド実行と `SHOW TABLES` 確認
  - [ ] AC-2：`messages/ja.json` と `messages/en.json` の全翻訳キー構造が完全一致していることを検証できる → 確認方法：翻訳キー比較の単体テスト
  - [ ] AC-3：`/ja/privacy`・`/en/privacy`・`/legal` に事業者名（合同会社Anaheim Eight）・外部送信／外国所在クラウド一覧・開示請求窓口・日本国内居住者向け明記が含まれ、`/en/terms` に日本語正文・日本法準拠条項が含まれ、ヘッダーから言語切替できる → 確認方法：HTTP レスポンス検証テストおよび画面確認
  - [ ] AC-4：`GET /api/healthz`（ロケール非依存）が DB 正常時 `200`、DB 切断時 `503` を返す → 確認方法：単体テストおよび `curl`

### 機能 2：`02-auth-account`（日英対応の認証・Turnstile＆レート制限・同意証跡・退会匿名化）
- **目的**：ボットや乗っ取りを防ぎつつ、日本語話者・英語話者の先生・生徒が規約同意証跡を残して安全に登録・ログイン・退会できるようにする。
- **対象範囲**：
  - やること：日英 UI でのメール＋パスワード登録（Argon2id）、新規登録・PW 再設定への Cloudflare Turnstile 検証＋`CF-Connecting-IP` 基準レート制限、登録時（Google OAuth 初回含む）の規約・プラポリ同意必須チェックと `terms_consented_at`・`privacy_consented_at`・`consented_policy_version` 記録、**確認済みメール（`email_verified_at IS NOT NULL`）のみ許可する Google OAuth 自動名寄せ**、`users.preferred_locale` 設定、生徒プロフィール編集（要配慮個人情報の記入禁止注意書き付き）、退会（個人情報匿名化＋R2 旧アバター削除）、`suspended` 遮断。
  - やらないこと：先生プロフィール詳細編集（機能 3）。
- **受け入れ条件**：
  - [ ] AC-1：Turnstile 検証失敗時・レート制限超過時・規約同意チェック無し時は登録が拒否され、正常同意時に同意日時・版数・`preferred_locale`・Argon2id ハッシュが保存される → 確認方法：単体テスト
  - [ ] AC-2：`email_verified_at` が NULL（未確認）の既存メールレコードに対して同一メールの Google ログインを行っても勝手に自動紐付けされず、確認済みメールのみ安全に紐付けされる → 確認方法：単体テスト
  - [ ] AC-3：未確認メール・誤パスワード・`suspended` 状態のログインが拒否され、退会時は `status = 'withdrawn'`・個人情報匿名化・R2 アバター削除が行われ再ログイン不可になる → 確認方法：単体テスト

### 機能 3：`03-teacher-profile-admin`（先生の日英プロフィール・R2 EXIF 除去＆旧画像削除・管理審査と監査ログ）
- **目的**：先生が対応言語と日英プロフィール・メニューを登録して審査申請でき、運営が監査ログ（`admin_audit_logs`）を残しながら管理審査・公開制御できるようにする。
- **対象範囲**：
  - やること：指導楽器マスタ（日英名付き）Seed、先生プロフィール編集（`speaks_japanese` / `speaks_english`、日英プロフィール項目、要配慮個人情報注意書き）、Cloudflare R2 画像アップロード（WebP リサイズ＋**EXIF 位置情報除去**＋**差し替え時の旧 `avatar_key` オブジェクト自動削除**）、YouTube URL 検証、メニュー CRUD、審査申請、`/admin` 管理画面（日英内容確認・承認・差し戻し・ユーザー停止）と **`admin_audit_logs`（`CF-Connecting-IP` 含む）への全管理操作記録**。
  - やらないこと：公開検索・SEO 出力（機能 4）。
- **受け入れ条件**：
  - [ ] AC-1：`speaks_japanese` と `speaks_english` のどちらも `false` の場合はエラーとなり、必須項目とメニュー 1 件以上を満たして申請すると `pending_review` になる → 確認方法：単体テスト
  - [ ] AC-2：2MB 超・非対応形式の画像や YouTube 以外の動画 URL が拒否され、EXIF GPS 付き JPEG の EXIF が除去され、再アップロード時に旧 R2 キーの削除処理が呼ばれる → 確認方法：モック・画像変換の単体テスト
  - [ ] AC-3：管理者ロール以外は `/admin/*` にアクセスできず（`403`）、管理者が承認・差し戻し・ユーザー停止を実行すると `CF-Connecting-IP` を含むレコードが `admin_audit_logs` に作成される → 確認方法：単体テストおよび画面確認

### 機能 4：`04-public-search-seo`（日英トップ・講師募集 FAQ・英語可フィルタ検索・先生詳細 SEO/`hreflang`）
- **目的**：日本語・英語双方の検索や SNS から訪れた生徒・講師候補が、迷わず検索・登録に進めるようにする。
- **対象範囲**：
  - やること：`/[locale]` トップ、`/[locale]/for-teachers` 募集 LP（**「インボイス未登録の個人・音大生・副業講師でも登録可能」を含む日英 FAQ 付き**）、`/[locale]/teachers` 検索（楽器・都道府県・オンライン・**英語レッスン可（`speaks_english`）**・体験料金上限・曜日）、`/[locale]/teachers/[slug]` 詳細 SSR（英語未入力時の日本語フォールバック表示、動的 OGP、`hreflang`、JSON-LD）、日英両 URL の `sitemap.xml`、`robots.txt`、会員・管理画面の `noindex`、GA4。
  - やらないこと：口コミ・お気に入り。
- **受け入れ条件**：
  - [ ] AC-1：公開条件（`approved` かつ `is_public` かつ `active`）を満たす先生のみが `/ja`・`/en` の一覧・詳細・`sitemap.xml` に出て、非公開講師は `404` になる → 確認方法：結合テスト
  - [ ] AC-2：「英語レッスン可（English available）」フィルタを有効にすると `speaks_english = true` の先生のみが返り、都道府県・楽器名が `/ja` では日本語、`/en` では英語で表示される → 確認方法：単体テストおよび画面確認
  - [ ] AC-3：`/en/teachers/[slug]` で英語未入力時は日本語フォールバックが表示され、両言語ページに相互の `hreflang` が出力され、`private_location_note` は一切含まれず、`/[locale]/for-teachers` にインボイス未登録可の FAQ が表示される → 確認方法：HTML レスポンス検証テスト
  - [ ] AC-4：会員ページ（`/[locale]/dashboard/*`, `/[locale]/teacher/*`）および `/admin/*` に `noindex` が付与される → 確認方法：レスポンス検証テスト

### 機能 5：`05-booking-chat`（日英リクエスト予約・テキスト限定 30 秒ポーリングチャット・確定情報開示・通報）
- **目的**：日本語・英語どちらの UI からでも希望日時（JST 明記）を送って予約・軽量ポーリングチャット・確定情報確認・通報ができるようにする。
- **対象範囲**：
  - やること：申し込みフォーム（メニュー選択、第 1〜3 希望日時［`JST (UTC+9)` 明記］、未成年時の保護者同意チェック、要配慮個人情報注意書き、スナップショット保存）、1 対 1 チャット（**テキストのみ・添付不可・上限 2,000 文字、アクティブタブ時のみ 30 秒間隔ポーリング**）、先生の確定・辞退・キャンセル・完了操作、確定後のみの通話 URL／詳細場所開示、Turnstile 付き通報フォーム（`/[locale]/reports/new`）と `/admin/reports`（`admin_audit_logs` 記録含む）。
  - やらないこと：サイト内カード決済、チャットへの画像・楽譜添付、ユーザー別タイムゾーン自動変換。
- **受け入れ条件**：
  - [ ] AC-1：未成年の受講で保護者同意チェックが無い場合は `400` で拒否され、申込成功時にスナップショットを持つ `requested` 予約が作られる → 確認方法：単体テスト
  - [ ] AC-2：当事者以外のアクセスは `403`/`404` で拒否され、`meeting_url_or_location` は `confirmed` 確定後にのみ生徒へ開示される → 確認方法：認可・状態別の単体テスト
  - [ ] AC-3：チャットで 2,000 文字超または空文字の送信が `400` で拒否され、予約詳細画面が `/ja` では日本語、`/en` では英語（`JST (UTC+9)` 付記）で表示される → 確認方法：単体テストおよび画面確認
  - [ ] AC-4：不正なステータス遷移が拒否され、日英通報フォームからの送信が `/admin/reports` で確認・更新でき、`admin_audit_logs` に記録される → 確認方法：単体テスト

### 機能 6：`06-notification-ops`（日英 Resend 通知・日次 4 処理バッチ［リマインド／期限切れ／自動完了／1 年マスク］・運用手順）
- **目的**：送信用サブドメイン（Resend）と受信用 Email Routing を分離した上で日英メール通知と日次自動保守バッチを安定稼働させる。
- **対象範囲**：
  - やること：Resend メール送信アダプタ（`noreply@mail.lesson.ana8labo.com`）、日英メールテンプレート一式（認証、PW リセット、申込、確定・辞退・キャンセル・期限切れ、チャット新着 15 分抑止、審査結果、前日リマインド）、日次定期ジョブ API（毎日 08:00 JST、`CRON_INTERNAL_TOKEN`：① 前日リマインド送信、② **申込から 7 日放置または全希望日時超過の `requested` 予約を自動で `expired` 化し通知**、③ **`confirmed_end_at` から 24 時間経過した `confirmed` 予約を自動で `completed` 化**、④ 終了系ステータスから 365 日経過した予約の詳細場所・支払案内・チャット本文自動マスク＋`pii_purged_at` 記録、⑤ Healthchecks ping / `/fail`）、本番公開・DNS（Resend × Email Routing）・個法安全管理・漏えい速報手順書。
  - やらないこと：LINE 通知、メルマガ一斉配信。
- **受け入れ条件**：
  - [ ] AC-1：生徒が `'en'`、先生が `'ja'` の予約において、先生宛は日本語、生徒宛は英語（`JST` 明記）のメールが生成・送信される → 確認方法：メールモックを用いた単体テスト
  - [ ] AC-2：同一予約スレッドで 15 分以内に複数回チャット送信しても過剰連投されない → 確認方法：単体テスト
  - [ ] AC-3：日次ジョブで ① 二重リマインド防止、② 7 日放置／希望日超過の `requested` → `expired` 自動遷移、③ 終了 24 時間経過の `confirmed` → `completed` 自動遷移、④ 終了 365 日経過データの自動マスク（364 日以内は保持）がそれぞれ正確に動く → 確認方法：境界日時の単体テスト
  - [ ] AC-4：日次ジョブが正常時 Healthchecks ping、例外時 `/fail` を呼び、トークン不正時は `401` を返す → 確認方法：単体テスト

---

## 10. `tasks.md` の素案（1 タスク半日以内・1 コミット目安）

### `01-foundation`
- [ ] T1：ブランチ作成、Next.js + `next-intl`（`/ja`, `/en` ルーティング・言語切替ヘッダー・辞書キー一致テスト）初期化　対応 AC：AC-2, AC-3
- [ ] T2：`Dockerfile` と `docker-compose.yml`（`sharednet`・ログローテーション・`.env.example`）の作成　対応 AC：AC-1
- [ ] T3：Prisma 初期スキーマ（英語カラム・同意証跡・`expired`・`pii_purged_at`・`admin_audit_logs` 含む全 MVP テーブル）とマイグレーション作成　対応 AC：AC-1
- [ ] T4：`GET /api/healthz`、`CF-Connecting-IP` 取得ヘルパー、DB 障害時の日英併記 503 エラーハンドリング実装・単体テスト　対応 AC：AC-4
- [ ] T5：個法・著作権条項準拠の `/[locale]/terms`・`/privacy`・`/legal`（合同会社Anaheim Eight・`support@lesson.ana8labo.com`・外部送信一覧・日本語正文注記含む）実装と全体テスト　対応 AC：AC-2, AC-3

### `02-auth-account`
- [ ] T1：ブランチ作成、Argon2id・認証トークン・Turnstile 検証＆`CF-Connecting-IP` レート制限ユーティリティの実装・単体テスト　対応 AC：AC-1
- [ ] T2：日英対応の新規登録（Turnstile・ロール選択・規約／プラポリ同意日時・版数・`preferred_locale` 保存）とメール確認処理　対応 AC：AC-1
- [ ] T3：ログイン／ログアウト／Google OAuth（確認済みメールのみ自動紐付け・初回同意画面経由）／`suspended`・`withdrawn` 遮断の実装・テスト　対応 AC：AC-1, AC-2, AC-3
- [ ] T4：Turnstile 付きパスワード再設定フローと生徒プロフィール・通知言語編集画面（要配慮個人情報注意書き付き）の実装　対応 AC：AC-1
- [ ] T5：退会処理（日英表示名・メール匿名化、R2 アバター削除、セッション破棄）の実装と全体テスト　対応 AC：AC-3

### `03-teacher-profile-admin`
- [ ] T1：ブランチ作成、日英楽器マスタ Seed 投入と先生プロフィール検証（対応言語必須・YouTube URL 検証）の単体テスト　対応 AC：AC-1, AC-2
- [ ] T2：Cloudflare R2 アップロード・旧オブジェクト自動削除処理（MIME・2MB 上限・WebP リサイズ・EXIF 除去検証）の実装・テスト　対応 AC：AC-2
- [ ] T3：先生プロフィール編集画面（日英入力タブ・対応言語・要配慮個人情報注意書き）とメニュー CRUD・審査申請の実装　対応 AC：AC-1
- [ ] T4：管理者ガード・`admin_audit_logs`（`CF-Connecting-IP` 付）記録と管理画面（`/admin/teachers` 審査、`/admin/users` 停止操作）の実装・テスト　対応 AC：AC-3
- [ ] T5：結合テスト通しと `impl-log.md` の仕上げ　対応 AC：AC-1〜AC-3

### `04-public-search-seo`
- [ ] T1：ブランチ作成、公開講師フィルタと複合検索クエリ（`speaks_english` 含む）の実装・単体テスト　対応 AC：AC-1, AC-2
- [ ] T2：日英対応の先生検索・一覧ページ（`/[locale]/teachers`、都道府県・楽器の日英表示）の実装　対応 AC：AC-1, AC-2
- [ ] T3：先生詳細 SSR ページ（`/[locale]/teachers/[slug]`、英語未入力時フォールバック、OGP、`hreflang`、JSON-LD）の実装・テスト　対応 AC：AC-1, AC-3
- [ ] T4：日英トップページ（`/[locale]`）と先生募集 LP（`/[locale]/for-teachers`、インボイス未登録可 FAQ 含む）の実装・テスト　対応 AC：AC-3
- [ ] T5：日英両 URL の `sitemap.xml`・`robots.txt`・会員/管理ページの `noindex`・GA4 組み込みと全体テスト　対応 AC：AC-1, AC-4

### `05-booking-chat`
- [ ] T1：ブランチ作成、予約ステータス遷移（`expired` 含む）・認可判定・キャンセル規定日英変換ロジックの実装と単体テスト　対応 AC：AC-2, AC-3, AC-4
- [ ] T2：日英対応の申し込み画面（`/[locale]/teachers/[slug]/book`、`JST` 明記・保護者同意・要配慮個人情報注意書き・スナップショット保存）の実装・テスト　対応 AC：AC-1, AC-3
- [ ] T3：生徒・先生双方の予約詳細画面と確定・辞退・キャンセル・完了操作、確定後情報開示制御の実装　対応 AC：AC-2, AC-3, AC-4
- [ ] T4：予約スレッド内の 1 対 1 チャット（テキスト限定 2,000 字上限・アクティブタブ時 30 秒ポーリング・既読更新）の実装・テスト　対応 AC：AC-2, AC-3
- [ ] T5：Turnstile 付き日英通報フォーム（`/[locale]/reports/new`）と `/admin/reports` 対応更新（`admin_audit_logs` 記録含む）の実装と全体テスト　対応 AC：AC-4

### `06-notification-ops`
- [ ] T1：ブランチ作成、Resend 送信アダプタと `preferred_locale` 対応の日英メールテンプレート（期限切れ通知含む）の実装・テスト　対応 AC：AC-1
- [ ] T2：認証・予約申込・確定・キャンセル・先生審査結果への日英メール通知組み込み　対応 AC：AC-1
- [ ] T3：チャット新着メールの 15 分間連投抑止ロジックの実装・テスト　対応 AC：AC-2
- [ ] T4：日次 4 処理ジョブ API（前日リマインド＋7 日放置/希望日超過 `expired`＋終了 24h 後 `completed`＋終了 365 日後自動マスク＋Healthchecks ping）の実装・境界テスト　対応 AC：AC-3, AC-4
- [ ] T5：本番公開・DNS（Resend サブドメイン × Cloudflare Email Routing）・個法安全管理・漏えい速報手順書の整備と全体確認　対応 AC：AC-1〜AC-4

---

## 11. 未決事項とリスク

### 未決事項（`01-foundation` 着手時または公開前までに決める残り 2 件）
1. **サービス表示名（日本語名・英語表記）の確定**
   - サブドメインは `lesson.ana8labo.com`、運営主体は **合同会社Anaheim Eight（Anaheim Eight LLC）**、窓口メールは **`support@lesson.ana8labo.com`**（Cloudflare Email Routing）、送信元は **`noreply@mail.lesson.ana8labo.com`**（Resend）で確定済み。
   - 画面上の日英サイト表示名（例：オトツナギ / OtoTsunagi、レッスンマッチ / LessonMatch など）を `01-foundation` 着手〜公開前までに決める（コード上は言語辞書と定数で一括置換可能にする）。
2. **Git リモート先と PR 運用**
   - GitHub に置くか Azure DevOps に置くか、また PR を出すか「PR を出さない運用（fast-forward push）」にするかを、`01-foundation` 着手時に決める。

### 主なリスクと対策
1. **初期の「鶏と卵問題」**：生徒集客の前に `/ja/for-teachers`・`/en/for-teachers` を用意し、手数料 0 円キャンペーンで日本人個人講師＋英語で教えられる講師を合計 10〜20 名スカウトしてから生徒募集を開く。
2. **英語利用規約・海外プライバシー法（GDPR 等）リスク**：日本国内居住者向けサービス（円建て・JST 基準）である旨と、日本法準拠・日本語正文を `/en/terms`・`/en/privacy` に明記して域外適用・翻訳解釈差リスクを抑える。
3. **個人情報保護法上の漏えい・長期保有リスク**：身分証非保持・EXIF 除去・1 年経過後の詳細場所／チャット自動マスク・退会時即時匿名化・`admin_audit_logs`・ホスト BitLocker／DB ポート制限により保有リスク自体を最小化し、万一の際の個情委速報（3〜5 日以内）ランブックを備える。
4. **日英の時差誤認・当事者間決済トラブル・月曜 4:00 DB 停止**：全日時への `JST (UTC+9)` 明記、規約明示＋通報によるアカウント停止、DB 停止時の日英併記 503 画面と 08:00 JST バッチ実行で対処する。
