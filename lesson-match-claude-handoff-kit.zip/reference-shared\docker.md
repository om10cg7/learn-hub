---
tags: [shared, infra, docker]
updated: 2026-11-24
---
# Docker の共通管理

常時起動マシン 1 台に同居するコンテナの、場所とポートと決まりを書く。全体の地図は [[shared/infra]] にある。
外部への公開は [[shared/cloudflare]]、DB は [[shared/db-credentials]] と [[shared/backup-policy]] に書く。
環境変数と設定の値は書かない。名前、場所、ポートだけを置く。

## 決まり（2026-11-24、岡本）
- ポートを足すときは、先にこのノートの「公開ポート」の表で空きを確かめ、決めたら表に書く
- ホストへの公開は `127.0.0.1` を基本にする。`0.0.0.0` で公開するのは、理由をこのノートに書いたものだけにする
- 外のネットワークに出すものは、ポートを開けず Cloudflare Tunnel（`sharednet` 経由）で出す
- `sharednet` に入れるコンテナは、サービス名の衝突を避けるため `container_name` かエイリアスを明示する（例: `yuzu-web`、`mitsumori-web`）
- 値の入った設定ファイル（`.env`、`docker-compose.override.yml`）は、コミットせず、チャットにも出さない
- コンテナを作り直すと中身が消えるものがある。作り直す前に、下の「作り直しの注意」を見る

## プロジェクトの場所（compose の作業フォルダ）

| プロジェクト | 場所 |
|---|---|
| stock | `C:\docker\STOCK` |
| mariadb | `C:\docker\mariadb` |
| docker（docker-speech） | `C:\dev\drive-jarvis\docker` |
| 下の「git フォルダ」にあるもの | 次の箇条書きを見る |

- git フォルダは `G:\onedrive\admin\OneDrive - イージーカンパニー\git\` である
- git フォルダの下に同名のフォルダがあるもの: bus-map、chirashiclip、cloudflare_tunnel、m2l、mail_mcp、
  ngrok、riders-map、tradereflect、train-delay、yuzu
- 名前が違うもの: mitsumori は `first\mitsumori`、creative-director は `sample site\creative-director`
- Ollama は compose を使わず、単体のコンテナ `ollama` で動く

## 公開ポート（ホスト側）
2026-11-24 に `docker ps -a` で確かめた。表の更新は、末尾の「棚卸し」の手順で行う。

| ポート | 公開先 | コンテナ | 用途 |
|---|---|---|---|
| `3000` | 127.0.0.1 | `tradereflect-frontend-1` | tradereflect の画面 |
| `3306` | 0.0.0.0 | `dev-mariadb` | 共用 DB。`host.docker.internal:3306` で使う |
| `3307` | 127.0.0.1 | `chirashiclip-db-1` | chirashiclip の DB（専用） |
| `5000` | 0.0.0.0 | `stock-simulator-1` | 株シミュレーター（`kabu` のトンネルの行き先） |
| `5001` | 0.0.0.0 | `mitsumori-web` | 見積り（`mitsumori` のトンネルの行き先） |
| `5002` | 0.0.0.0 | `m2l-m2l-1` | m2l |
| `8000` | 127.0.0.1 | `train-delay-web-1` | train-delay の確認用 |
| `8080` | 0.0.0.0 | `yuzu-web-1` | yuzu |
| `8090` | 127.0.0.1 | `tradereflect-backend-1` | tradereflect の API |
| `8091`、`8092`、`8093`、`8095` | 127.0.0.1 | `bus-map-*-web` | bus-map の地域ごとの web（広島 8091、熊本 8092、富山 8093、群馬 8095） |
| `8094` | 127.0.0.1 | `riders-map-api-1` | riders-map の API |
| `8096` | 127.0.0.1 | `chirashiclip-app-1` | chirashiclip |
| `8100` | 127.0.0.1 | `docker-speech-1` | 音声 |
| `11434` | 0.0.0.0 | `ollama` | Ollama |
| `8200` | （ホストで待ち受け） | madoreno の API | `chat` のトンネルの行き先。コンテナの公開ポートではない |

停止中のコンテナが `3000`（creative-director）、`3025`、`3143`、`3993`（mail_mcp の greenmail）、`4040`（ngrok）を予約している。

## 確認が要る項目
- `3000` を `tradereflect-frontend-1`（動作中）と `creative-director-web-1`（停止中）が使う。creative-director を起動すると、取り合いになる
- `0.0.0.0` で公開している `3306`、`5000`、`5001`、`5002`、`8080`、`11434` は、LAN からも届く。
  トンネルだけで済むものを `127.0.0.1` にできるかを、プロジェクトごとに確かめる（変えるときは、そのプロジェクトの担当の確認を取る）
- `3306` の DB は、コンテナからは `host.docker.internal:3306` で使う。`127.0.0.1` にしても動くかは、試していない
- `riders-map` の compose の作業フォルダに、この Vault の `projects\Rriders-map\infra` を指すコンテナがある。意図したものかを確かめる
- 停止中のコンテナが 4 つある。使わないものは消す
  - `ngrok-ngrok-1`
  - `mail_mcp-greenmail-1`
  - `riders-map-test-db-1`
  - `creative-director-web-1`

## ネットワーク
- `sharednet`: Cloudflare Tunnel と、その行き先のコンテナが入る。DB（`dev-mariadb`）も入っている
- プロジェクトごとの `<名前>_default` は、各 compose が作る
- 参加者の一覧は、棚卸しの出力に出る

## 作り直しの注意
- `ollama`: モデルは `gemma2:9b` と `nomic-embed-text`。コンテナを作り直したら入れ直す
- 共用 DB（`dev-mariadb`）: データはボリュームにある。ボリュームの複製は [[shared/backup-policy]] に書いた週次の作業が行う
- 名前付きボリュームは約 67 個ある。`docker volume prune` と `docker system prune --volumes` は使わない

## 棚卸し（読み取りだけ）
「インフラ棚卸し」と頼むと、次を行う。

```bash
python shared/tools/infra_inventory.py --note shared/docker.md
```

- 公開ポートの表、ポートの重なり、`0.0.0.0` での公開、`sharednet` の参加者を出す
- ノートに無いポートを知らせる。差分があれば、このノートの表を更新する
- コンテナの設定や環境変数の値は読まない
