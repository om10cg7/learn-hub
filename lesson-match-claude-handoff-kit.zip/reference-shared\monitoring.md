---
tags: [shared, infra, monitoring]
updated: 2026-11-24
---
# 死活監視の共通管理

全プロジェクトの死活監視を、3 つの層と 1 つの通知先にそろえる。全体の地図は [[shared/infra]]、コンテナとポートは [[shared/docker]] にある。
ping の URL とトークンは、このノートにも他のノートにも書かない。名前と役割だけを置く。

## 決定（2026-11-24、岡本）
- 監視は 3 つの層に分ける。層ごとに道具を決める
- 通知先は Slack に 1 つにそろえる。メールは予備にする
- 通知先のチャンネルは、アラート専用の `#アラート` にする（2026-11-24 に作成）。「#テスト用の通知」は使わない
- 外から見る層の道具は、無料の UptimeRobot にする
- チェックの名前は `<プロジェクト>-<役割>` にそろえる（例: `stock-batch`、`m2l-web`）

## 3 つの層

| 層 | 見るもの | 道具 | 状況 |
|---|---|---|---|
| 1 コンテナ | 落ちた、unhealthy、再起動の繰り返し | `shared/tools/docker_watch.py` と Healthchecks.io | 2026-11-24 に稼働。タスク `docker-watch` が 5 分おきに動く |
| 2 ジョブ | batch、collector、バックアップが期限内に終わったか | Healthchecks.io | bus-map とバックアップだけ設定済み |
| 3 外から | 公開ホストに届くか（PC やトンネルの停止を含む） | UptimeRobot（無料） | 2026-11-24 に 4 件を登録。通知はメールだけ |

- 層 1 はプロジェクト側の改修が要らない。Docker の状態だけを見る
- 層 3 が要るのは、PC やネットワークが止まると、PC の中の監視も一緒に止まるからである

## 層 1: コンテナの監視
- `docker_watch.py` は、5 分おきに `docker ps -a` を見る。動かし方はスクリプト冒頭の説明に従う
- 異常とみなすのは、下の「停止していてよいコンテナ」に無い停止、`unhealthy`、再起動の繰り返し
- 結果は Healthchecks.io のチェック `docker-host` に送る。異常なしなら ping、異常ありなら `/fail` と一覧を送る
- ping が止まった（PC が止まった、スクリプトが動かない）ときも、猶予が過ぎると Healthchecks.io が知らせる。
  周期は 5 分、猶予は 10 分にする
- ping の URL は環境変数 `HC_DOCKER_URL` に置く。置き場所は `C:\docker\monitoring\watch.env`（コミットしない）
- Windows のタスクスケジューラのタスク `docker-watch` が、`C:\docker\monitoring\run_watch.ps1` を 5 分おきに動かす。
  ログオン中だけ動く設定である（Docker Desktop もログオンが前提）。結果は同じフォルダの `watch.log` に残る

## 停止していてよいコンテナ
2026-11-24 時点で、停止していても異常としないものである。使わなくなったら消して、この表から外す。

- `ngrok-ngrok-1`
- `mail_mcp-greenmail-1`
- `riders-map-test-db-1`
- `creative-director-web-1`

## 層 2: ジョブの監視

| チェック | 相手 | 周期と猶予 | 状況 |
|---|---|---|---|
| MariaDB daily backup | `C:\docker\mariadb` のバックアップ | 1 日、猶予 4 時間 | 設定済み（[[shared/backup-policy]]） |
| bus-map の worker と web | bus-map | 設定は Healthchecks.io 側 | 設定済み。富山の要否は未定 |
| `stock-batch` | STOCK の batch | 未定 | 未設定。`stock_batch` への移行と同時に足す |
| `stock-simulator` | STOCK のシミュレーター | 未定 | 未設定。層 3 で足りるかも見る |

- 他のプロジェクトのジョブ（collector、backup など）は、担当の確認を取ってから足す
- ジョブは、成功したら ping し、失敗したら `/fail` に送る。猶予は、実行にかかる時間に余裕を足して決める

## 層 3: 外からの監視
公開ホストは [[shared/cloudflare]] の表にある。UptimeRobot には、次を 5 分おき（無料の最短）の HTTP で登録した（2026-11-24）。

- `kabu.ana8labo.com`、`chat.ana8labo.com`、`yuzu.ana8labo.com`、`mitsumori.ana8labo.com`
- `bus`、`tradereflect`、`train-archive` は、Cloudflare のホスト名の照合が終わってから足す
- 通知はメールだけである。Slack と Webhook の連携は有料プランの機能なので、使わない（購入は岡本が決める）
- PC が止まったときは、層 1 の ping が止まり、Healthchecks.io から Slack に届く。UptimeRobot のメールは、トンネルや DNS の障害の予備になる

## 通知
- Healthchecks.io から Slack への連携は、2026-11-24 に設定した。層 1 と層 2 の通知が、メールに加えて `#アラート` に届く。
  連携は Slack の Incoming Webhook の URL を貼る形式で、10 件すべてのチェックに割り当てた。
  同日に `docker-host` へ失敗の ping を送り、DOWN と UP の両方が届くことを確かめた
- アラート専用のチャンネル `#アラート` を、個人用ワークスペース `test` に作った（2026-11-24）。
  Slack アプリ `test` の Incoming Webhooks に、このチャンネル向けの Webhook を発行済みである
- Webhook の URL は、Slack の画面の「Copy」から、Healthchecks.io の連携の画面に直接貼った（値は他に書かない）
- UptimeRobot は、無料プランでは Slack に送れない。メールで受ける
- 既存の Slack Webhook は、チャットに出た経緯があるので、使い続けるなら再発行する（[[shared/db-credentials]] の「守ること」も見る）

## 新しいプロジェクトを足すとき
1. [[shared/docker]] の公開ポートの表に足す
2. コンテナは、`docker_watch.py` が自動で見る。停止してよいものは、この表に足す
3. 定期ジョブがあれば、層 2 の表に足し、Healthchecks.io にチェックを作る
4. 外に公開するなら、層 3 に足す

## 未決事項
- アラート専用の Slack チャンネルの名前
- Healthchecks.io の無料枠で、チェックの数が足りるか（2026-11-24 時点で 10 件。上限は画面で確かめる）
- ログオンしていない間（再起動の直後など）も見るか。見るなら、パスワードつきのタスクに変える
