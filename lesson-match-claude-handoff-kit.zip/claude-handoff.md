---
tags: [project, lesson-match, handoff, claude]
updated: 2026-11-25
---

# lesson-match Claude Code 引き継ぎ書

Gemini との対話で確定した全体仕様・改正個人情報保護法（個法）対応・運用エッジケースを、Claude Code の司令塔セッション（Opus 5.5）へ引き継ぐための実行仕様書である。

## 位置づけと最初に読むファイル

司令塔セッションは作業を始める前に、次の順番でノートを読む:

1. [[projects/lesson-match/_overview|lesson-match _overview]]（現状・公開先・KPI 定義）
2. [[projects/lesson-match/decisions|decisions]]（全設計判断の背景・選択肢・採用理由）
3. [[projects/lesson-match/handoff/spec-draft|spec-draft]]（全 11 章の全体仕様・データモデル・MVP 6 機能の素案）
4. [[shared/dev-workflow]] と `.claude/skills/stage-start/SKILL.md`（設計→実装→独立検証→振り返りの手順）
5. [[shared/docker]]・[[shared/cloudflare]]・[[shared/monitoring]]・[[shared/backup-policy]]（共用インフラ規約）

## 着手前の未決確認とリポジトリ初期化手順

`設計開始 01-foundation` に入る時点で、未決事項は次の 2 件だけである。最初に岡本へ確認して確定させる:

- サイト表示名（日本語名・英語表記。未定のまま進む場合は設定定数 `SITE_NAME_JA` / `SITE_NAME_EN` に仮置きする）
- Git リモート先（GitHub か Azure DevOps か）と PR 運用（PR を出すか、TradeReflect 同様に PR を出さない `fast-forward push` 運用にするか）

`01-foundation` の設計・初期化では次の手順を必ず踏む:

1. リポジトリを `G:\onedrive\admin\OneDrive - イージーカンパニー\git\lesson-match` に作成する。
2. **`.gitignore` に `.claude/worktrees` と `.env` と `.env.*`（`.env.example` を除く）を最初から入れる**。入れ忘れると `実装開始` のワークツリー作成時に未追跡ファイルが混ざる。
3. 実機で `Get-NetTCPConnection -State Listen` と `docker ps -a` を実行し、ローカル確認用ポート候補 `127.0.0.1:8097`・コンテナ名 `lesson-match-web`・DB 名 `lesson_match` が既存環境と衝突しないことを確かめ、実行コマンドと確認日を `01-foundation` の `spec.md`「現状の作り」に記録する。

## 司令塔が spec.md を書く際の必須ルール

- **実装役（Sonnet サブエージェント）と独立検証役（Opus サブエージェント）には `spec-draft.md` も `decisions.md` も渡されない**。各機能の `spec.md` を作るときは、対象機能に必要なテーブル定義・カラム型・バリデーション上限・エラー時の HTTP ステータスと画面挙動を省略せず `spec.md` に自己完結で転記する
- 単体テストで確かめる受け入れ条件（AC）には、DB や Next.js のリクエストコンテキスト無しで呼べる純粋関数名を `spec.md` の「仕様」に明記する。密結合になりそうな処理は関数切り出しを `tasks.md` の独立タスクにする
- 機能は必ず次の依存順で 1 本ずつ完了（`retro.md` 作成）させてから次へ進む:
  - `01-foundation` → `02-auth-account` → `03-teacher-profile-admin` → `04-public-search-seo` → `05-booking-chat` → `06-notification-ops`

## 全機能で守る技術・セキュリティ不変条件

### ルーティングと i18n 境界

- Next.js（App Router / TypeScript / `output: "standalone"`）と `next-intl` を使う
- ユーザー向け画面は `/ja/...` と `/en/...` のロケールプレフィックス配下に置く。ルート `/` は `Accept-Language` と Cookie を見て `/ja` または `/en` へリダイレクトする
- **次のパスは `next-intl` ミドルウェアのロケール付与対象から必ず除外する**:
  - `/api/healthz`（UptimeRobot 層 3 監視・Docker healthcheck 用）
  - `/api/internal/*`（日次バッチ用）
  - `/api/auth/*`（OAuth コールバック用）
  - `/admin` および `/admin/*`（運営専用のため日本語固定 UI とし、Cloudflare Access のパス保護条件 `/admin*` を単一に保つ）
  - `/sitemap.xml`, `/robots.txt`
- `messages/ja.json` と `messages/en.json` のキー構造完全一致を単体テストで強制する

### DB 接続・権限分離・週次停止対策

- 共用 MariaDB コンテナ `dev-mariadb`（文字コード `utf8mb4`）に DB `lesson_match` を作る。専用 DB コンテナは作らない
- DB ユーザーは用途別に 3 つへ分離し、`lesson_match.*` 以外に権限を与えない:
  - `lesson_match_web`: `SELECT, INSERT, UPDATE, DELETE` のみ（`admin_audit_logs` に対する `UPDATE, DELETE` はアプリコード上で禁止し、可能なら DB 権限でも絞る）
  - `lesson_match_batch`: `SELECT, UPDATE` のみ（日次ジョブ専用）
  - `lesson_match_migrate`: `prisma migrate deploy` 実行時のみ使う DDL 権限ユーザー。**本番や共用 DB に対して `prisma migrate dev`（Shadow DB 作成権限を要求するコマンド）を実行しない**
- 毎週月曜 04:00 JST にボリューム複製で `dev-mariadb` が一時停止するため、DB 接続失敗時はスタックトレースを出さず、日英併記の 503 メンテナンス応答を返す

### 日時・タイムゾーン規則

- DB の `DATETIME` カラムはすべて UTC で保存し、アプリの入出力境界で `Asia/Tokyo`（UTC+9）と相互変換する
- 画面表示とメール本文の日時は、日本語 UI では `2026年12月10日(木) 19:00 JST`、英語 UI では `Dec 10, 2026 19:00 JST (UTC+9)` のように **必ず `JST` または `JST (UTC+9)` を明記する**

### 認証・ボット対策・実 IP 取得

- パスワードは `@node-rs/argon2` の `Argon2id` でハッシュ化する
- **Google OAuth ログイン時の既存アカウント自動紐付けは、`users.email_verified_at IS NOT NULL` のレコードにのみ許可する**。未確認メールのレコードへ自動紐付けすると事前登録によるアカウント乗っ取りが成立するため拒否する
- Cloudflare Tunnel（`sharednet`）経由のリクエストではソケット IP が `cloudflared` の内部 IP になるため、クライアント IP は `CF-Connecting-IP` ヘッダー（未設定のローカル環境のみ `x-forwarded-for` または `127.0.0.1`）から取得する共通関数 `getClientIp(headers)` を作る
- 新規登録・パスワード再設定・通報フォームには Cloudflare Turnstile トークン検証と `CF-Connecting-IP` 基準のレート制限を必須とする。単体テスト・ローカル検証では `NODE_ENV === "test"` または検証モック注入で差し替え可能にする

### 画像ストレージ・ログ・管理監査

- プロフィール画像は Cloudflare R2 に保存する。アップロード受け付け条件は JPG / PNG / WebP かつ 2MB 以下とし、`sharp` 等で最大 800x800px の WebP に変換する際 **EXIF メタデータ（GPS 位置情報を含む）を完全に除去する**
- プロフィール画像の差し替え時とユーザー退会時には、古い `avatar_key` のオブジェクトを R2 から削除する
- 紹介動画は YouTube URL のみ許可し、ホスト名を検証したうえで `https://www.youtube-nocookie.com/embed/<VIDEO_ID>` 形式に変換して埋め込む（任意 iframe や `javascript:` スキームを許さない）
- アプリログは `pino` で JSON 構造化ログを標準出力に出し、Docker `json-file`（`max-size: "10m"`, `max-file: "5"`）でローテーションする。**`email`, `password`, `token`, `body`, `meeting_url_or_location`, `private_location_note` は `redact` 設定で必ずマスクする**
- `/admin/*` は Cloudflare Access に加え、アプリ側でもログインユーザーのメールが環境変数 `ADMIN_EMAILS` に含まれかつ `role === "admin"` であることを検証する。承認・差し戻し・アカウント停止・通報更新はすべて `admin_audit_logs` に `CF-Connecting-IP` 付きで記録する

## 改正個人情報保護法と法務の実装契約

- 第 32 条公表事項: `/[locale]/privacy` と `/[locale]/legal` に、運営主体 `合同会社Anaheim Eight`（英語 `Anaheim Eight LLC`）・登記上の本店所在地・代表者氏名・窓口メール `support@lesson.ana8labo.com` を明記する（住所・代表者名の実文字列は定数または環境変数から注入できる形にし、リポジトリ公開可否に合わせる）
- 海外法令（GDPR 等）回避と準拠法: 日英の規約・プラポリに「日本国内居住者（在日外国人を含む）を対象としたサービス（日本円 `JPY` 建て・`JST` 基準）であり、EEA・英国等の海外居住者を対象とした勧誘・提供を行わない」「準拠法は日本法とし、日本語版を正文（英語版は参考訳）とする」と明記する
- 第 28 条・外部送信規律: プラポリに外部サービス一覧表（米国 Cloudflare［Tunnel/CDN/Turnstile/Email Routing/Access/R2］、米国 Resend［メール配信］、米国 Google［OAuth/GA4/YouTube 埋め込み］、米国 Microsoft［OneDrive 日次バックアップ］）と米国の制度概要・GA4 オプトアウト案内を掲載する
- 第 27 条・第 20 条 2 項: 新規登録時（Google 初回登録時のロール選択画面を含む）に規約・プラポリへの明示同意チェックを必須とし、`terms_consented_at`, `privacy_consented_at`, `consented_policy_version` を保存する。プロフィール・申込・チャット入力欄には「病歴・心身の障がい等の要配慮個人情報は記入しない」旨の注意書きを表示する
- 著作権保護: 利用規約の禁止事項に「市販楽譜・音源・教則本等の著作物の無断複製・スキャン・データ共有」を明記し、チャットはテキストのみ（添付不可・上限 2,000 文字）とする

## 日次バッチと状態遷移の厳密な境界式

### 予約ステータスの許可遷移

| 遷移元 | 遷移先 | 実行可能主体 | 条件・備考 |
|---|---|---|---|
| `requested` | `confirmed` | 担当の先生のみ | `confirmed_start_at`, `confirmed_end_at`, `meeting_url_or_location` が必須 |
| `requested` | `declined` | 担当の先生のみ | 辞退理由（任意）を記録 |
| `requested` | `cancelled` | 申込した生徒・管理者 | キャンセル実行者ロールを記録 |
| `requested` | `expired` | 日次バッチのみ | 放置または全希望日時超過 |
| `confirmed` | `completed` | 担当の先生・日次バッチ | 手動完了は `confirmed_start_at` 以降のみ許可 |
| `confirmed` | `cancelled` | 生徒・先生・管理者 | キャンセル規定スナップショットを参照表示 |

上記以外の遷移はすべて `400`（権限不一致は `403`）で拒否する。また `meeting_url_or_location` と `payment_instruction` は、`status` が `confirmed` または `completed`（かつ `pii_purged_at IS NULL`）のときだけ生徒側レスポンスに含める。

### 毎日 08:00 JST 定期ジョブ（`POST /api/internal/cron/daily`）の判定式

ヘッダー `Authorization: Bearer <CRON_INTERNAL_TOKEN>` が一致しない場合は `401` を返す。実行基準時刻を `now`（UTC）、JST 換算での「翌日 00:00:00 JST 〜 翌日 23:59:59.999 JST」に対応する UTC 区間を `[nextDayStartUtc, nextDayEndUtc)` としたとき、次の 4 処理を順に実行する:

1. 前日リマインド送信:
   - 条件: `status = 'confirmed'` かつ `reminded_at IS NULL` かつ `confirmed_start_at >= nextDayStartUtc` かつ `confirmed_start_at < nextDayEndUtc`
   - 処理: 生徒・先生それぞれの `preferred_locale` でリマインドメールを送り、`reminded_at = now` に更新する
2. 放置リクエストの自動期限切れ:
   - 条件: `status = 'requested'` かつ（`created_at <= now - INTERVAL 7 DAY` または `GREATEST(candidate_slot_1, COALESCE(candidate_slot_2, candidate_slot_1), COALESCE(candidate_slot_3, candidate_slot_1)) < now`）
   - 処理: `status = 'expired'` に更新し、生徒へ期限切れ通知メールを送る
3. 受講終了後の自動完了:
   - 条件: `status = 'confirmed'` かつ `confirmed_end_at <= now - INTERVAL 24 HOUR`
   - 処理: `status = 'completed'` に更新する
4. 終了後 365 日経過データの自動マスク（個情法第 22 条）:
   - 条件: `status IN ('completed', 'cancelled', 'declined', 'expired')` かつ `pii_purged_at IS NULL` かつ `updated_at <= now - INTERVAL 365 DAY`
   - 処理: `meeting_url_or_location = NULL`, `payment_instruction = NULL` に更新し、紐づく `booking_messages.body` を `"[Deleted per 1-year retention policy / 保存期間経過により自動消去]"` に上書きし、`pii_purged_at = now` を記録する

4 処理すべてが例外なく完了したら `HC_REMINDER_PING_URL`（チェック名 `lesson-match-reminder`）へ GET/POST ping を送り、1 つでも未捕捉例外が出た場合は `<HC_REMINDER_PING_URL>/fail` を呼んでステータス `500` を返す。

## MVP 機能別の引き継ぎ要点

全カラム定義とタスク素案は [[projects/lesson-match/handoff/spec-draft|spec-draft]] の第 5・9・10 章を参照し、各機能で次の急所を落とさないこと:

- `01-foundation`: Prisma 全テーブル初期マイグレーション、`next-intl` 辞書キー一致テスト、`/api/healthz`、`getClientIp`、個法・著作権準拠の `/[locale]/terms`・`/privacy`・`/legal`
- `02-auth-account`: Argon2id、Turnstile＋レート制限、規約・プラポリ同意日時保存、`email_verified_at` 確認済み限定の Google 自動紐付け、退会時の日英名匿名化＋R2 旧アバター削除
- `03-teacher-profile-admin`: 日英楽器 Seed、`speaks_japanese` / `speaks_english`、R2 WebP 変換＋EXIF 除去＋旧画像削除、YouTube `youtube-nocookie.com` 変換、`/admin` 審査・停止と `admin_audit_logs` 記録
- `04-public-search-seo`: 公開 3 条件（`approved`・`is_public`・`active`）の厳格フィルタ、`speaks_english` 絞り込み、英語未入力時の日本語フォールバック表示、`hreflang`、日英 `sitemap.xml`、講師募集 LP の「インボイス未登録でも登録可」FAQ、`private_location_note` 非露出テスト
- `05-booking-chat`: 未成年時の保護者同意必須チェック、申込スナップショット保存、確定後のみの場所・URL 開示、テキスト限定 2,000 字チャット（`document.visibilityState === "visible"` の間のみ 30 秒ポーリング）、Turnstile 付き通報と管理対応
- `06-notification-ops`: `preferred_locale` 別の Resend 日英メール、チャット新着メールの 15 分連投抑止、上記 4 処理の日次バッチと境界単体テスト、本番公開・個情委漏えい速報（発覚後 3〜5 日以内）手順書

## 本番公開前に人間と司令塔で行うインフラ作業

`06-notification-ops` 完了から公開までの間に、次のインフラ設定と記録更新を行う:

1. `dev-mariadb` に DB `lesson_match` と 3 ユーザー（`web`, `batch`, `migrate`）を作成し、[[shared/db-credentials]] の手順に従って管理する（値は Vault に書かない）。あわせて `dev-mariadb` の `0.0.0.0:3306` を `127.0.0.1:3306` へ絞れるか検証し、ホスト PC の BitLocker 有効化を確認する。
2. Cloudflare で R2 バケット作成、Turnstile サイトキー発行、Email Routing（`support@lesson.ana8labo.com` 転送）設定、Resend 用サブドメイン `mail.lesson.ana8labo.com` の SPF / DKIM / MX 追加を行う。
3. コンテナ `lesson-match-web` を `sharednet` に入れ、Zero Trust で Tunnel `ana8labo-tunnel` に `lesson.ana8labo.com -> http://lesson-match-web:3000` を追加し、`/admin*` に Cloudflare Access ポリシーを設定する。同日に [[shared/docker]] と [[shared/cloudflare]] の表を更新する。
4. Healthchecks.io に `lesson-match-reminder`（周期 1 日・猶予 2 時間・Slack `#アラート` 連携）、UptimeRobot に `lesson-match-web`（`https://lesson.ana8labo.com/api/healthz`・5 分間隔）を登録し、ホストのタスクスケジューラで毎日 08:00 JST のバッチ呼び出しを設定して [[shared/monitoring]] を更新する。
