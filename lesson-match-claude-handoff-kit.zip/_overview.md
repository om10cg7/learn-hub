---
tags: [project, lesson-match]
updated: 2026-11-25
---
# lesson-match

楽器の先生と生徒をつなぐ日英バイリンガル対応（`/ja`, `/en`）のマッチングサイトを作る。
生徒が先生を探して体験レッスンや通常（単発）レッスンを希望日時つきで申し込み、チャットで確定して受講する形をとる。
全体仕様ドラフトは [[projects/lesson-match/handoff/spec-draft|spec-draft]]、各設計判断の経緯は [[projects/lesson-match/decisions|decisions]]、Claude Code への実行引き継ぎ書は [[projects/lesson-match/handoff/claude-handoff|claude-handoff]] にある。

## 現状
- 段階: 全体仕様・Claude Code 引き継ぎ書まで完成（MVP を 6 機能に分割済み。機能別の本設計・リポジトリ作成前）
- 仕様策定プロンプトを改善し、全体仕様書ドラフトと Claude Code 引き継ぎ書を作成済み（[[projects/lesson-match/handoff/gemini-spec-prompt|gemini-spec-prompt]]、[[projects/lesson-match/handoff/spec-draft|spec-draft]]、[[projects/lesson-match/handoff/claude-handoff|claude-handoff]]）
- リポジトリはまだ無い

## 場所
- リポジトリ予定: `G:\onedrive\admin\OneDrive - イージーカンパニー\git\lesson-match`（未作成）
- 公開先予定: `https://lesson.ana8labo.com`（`sharednet` 上の `lesson-match-web:3000`）

## 技術構成（決定済み）
- Web / i18n: Next.js (App Router / TypeScript / standalone) + `next-intl`（`/ja`, `/en`）
- DB / ORM: 共用 MariaDB（`dev-mariadb` の `lesson_match`）+ Prisma Migrate
- 認証 / 外部サービス: メール＋Argon2id パスワード＋Google OAuth、メール送信は Resend（日英出し分け）、プロフィール画像は Cloudflare R2、紹介動画は YouTube 埋め込み
- 管理画面保護: `/admin` を Cloudflare Access + アプリ側管理者ロールで二重保護

## 前提にする共用インフラ
- DB は共用の `dev-mariadb` に `lesson_match` と用途別ユーザー（web / batch / migrate）を作る（[[shared/infra]]、[[shared/db-credentials]]）
- コンテナは `sharednet` に入れ、Cloudflare Tunnel で公開する（[[shared/docker]]、[[shared/cloudflare]]）
- 死活監視は 3 層（`docker_watch.py` / Healthchecks `lesson-match-reminder` / UptimeRobot `lesson-match-web`）で見る（[[shared/monitoring]]）。バックアップは日次ダンプに含める（[[shared/backup-policy]]）
- 公開後のアクセス分析は [[shared/analysis-policy]] に従う

## アクセス分析（公開後の基準）
- 成果指標（KGI）: ① 審査承認・公開中の先生数（初期目標 10〜20 名、うち英語対応講師数も追跡）、② リクエスト予約申込数、③ 予約確定数
- 中間指標（KPI）: `/ja`・`/en` 別の検索流入セッション数、先生詳細ページ（`/[locale]/teachers/[slug]`）閲覧数、先生募集 LP（`/[locale]/for-teachers`）からの登録遷移率
- 守ること: 運営者アクセスを除外し、URL やイベント属性に氏名・メール等の個人情報を入れない

## 決定事項
- 2026-11-24: プロジェクト名を `lesson-match` とする（仮）。演奏者どうしではなく先生と生徒のマッチングにする
- 2026-11-25: 全体仕様と MVP 6 機能分割を確定した（経緯と理由は [[projects/lesson-match/decisions|decisions]]、詳細は [[projects/lesson-match/handoff/spec-draft|spec-draft]]）
  - MVP は完全無料・当事者間支払いで開始し、先に先生 10〜20 名をスカウトしてから生徒募集を開く
  - MVP から日英バイリンガル対応（`/ja`, `/en` UI・規約・通知メール＋英語レッスン可フィルタ＋任意の英語プロフィール欄）を必須とする
  - 改正個人情報保護法（個法）対応を確定：運営主体は「合同会社Anaheim Eight（Anaheim Eight LLC）」として第 32 条事項を公表、日本国内居住者向け明記で GDPR 域外適用を回避、同意日時 DB 記録・1 年経過データの自動マスク・EXIF 除去・`admin_audit_logs`・`3306` 制限検証・漏えい速報ランブックを組み込む
  - 運用・セキュリティ細部を確定：Cloudflare Turnstile＋`CF-Connecting-IP` レート制限、送信 `noreply@mail.lesson.ana8labo.com`（Resend）と窓口受信 `support@lesson.ana8labo.com`（Cloudflare Email Routing）の分離、放置予約の自動 `expired`／終了 24h 後の自動 `completed`、確認済みメールのみ Google 自動名寄せ、楽譜等著作物の無断共有禁止、R2 旧画像の自動削除

## 次にやること
- サービス表示名（日本語・英語）および Git リモート先と PR 運用の有無を決める
- Claude Code（Opus 5.5 司令塔セッション）で [[projects/lesson-match/handoff/claude-handoff|claude-handoff]] を読ませ、リポジトリ作成と「設計開始 `01-foundation`」を実行する

## 関連
- [[projects/lesson-match/handoff/claude-handoff|Claude Code 引き継ぎ書（claude-handoff）]]
- [[projects/lesson-match/decisions|設計判断（decisions）]]
- [[projects/lesson-match/handoff/spec-draft|仕様書ドラフト（spec-draft）]]
- [[projects/lesson-match/handoff/gemini-spec-prompt|仕様策定プロンプト（gemini-spec-prompt）]]
- [[projects/lesson-match/log/2026-11-25|作業ログ 2026-11-25]]
- [[00-dashboard]]
