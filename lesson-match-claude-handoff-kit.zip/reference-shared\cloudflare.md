---
tags: [shared, infra, cloudflare]
updated: 2026-11-24
---
# Cloudflare の共通管理

ドメインと Cloudflare Tunnel の、名前と行き先と決まりを書く。コンテナとポートは [[shared/docker]]、全体の地図は [[shared/infra]] にある。
トークン、API キー、アカウントのメールアドレスは書かない。名前と役割だけを置く。

## 決定（2026-11-24、岡本）
- 外部への公開は、ngrok をやめて Cloudflare Tunnel に一本化する（2026-08 に移行を開始）
- ホスト名と行き先は、このノートの表を基準にする。足したり変えたりしたら、同じ日にこの表を更新する
- トンネルの設定は、当面ダッシュボードの操作を正とする。Terraform へ移すかは、別に決める

## 構成

| 項目 | 内容 |
|---|---|
| ドメイン | `ana8labo.com`。2026-08-05 に Cloudflare Registrar で購入 |
| トンネル | `ana8labo-tunnel`（1 本だけ） |
| cloudflared | コンテナ `cloudflare_tunnel-cloudflared-1`。ネットワークは `sharednet` |
| compose の場所 | `G:\onedrive\admin\OneDrive - イージーカンパニー\git\Cloudflare_tunnel` |
| トークンの置き場所 | 上のフォルダの `.env`（`TUNNEL_TOKEN`）。コミットしない |

- cloudflared はトークンをコマンドの引数で受ける。`docker inspect` や `docker ps --no-trunc` に値が出るので、画面とチャットに出さない
- トンネルの行き先は、`sharednet` にいるコンテナの名前で書く。ホスト上のサービスは `host.docker.internal:<ポート>` で書く

## ホスト名と行き先
2026-11-24 時点の、わかっている範囲である。「要確認」は、ダッシュボードで照合してから埋める。

| ホスト名 | 行き先 | 確認元 |
|---|---|---|
| `kabu.ana8labo.com` | `http://web:5000`（STOCK の simulator） | Terraform の定義 |
| `chat.ana8labo.com` | `http://host.docker.internal:8200`（SHINKEN の AI チャット、madoreno の API） | [[shared/infra]]（2026-11-23 に 8000 から移した） |
| `yuzu.ana8labo.com` | `http://yuzu-web:80` | Terraform の定義 |
| `mitsumori.ana8labo.com` | `http://mitsumori-web:5001` | Terraform の定義 |
| `bus.ana8labo.com` | 要確認（bus-map の web のどれか） | [[shared/infra]] |
| `tradereflect.ana8labo.com` | 要確認（`tradereflect-proxy-1` と思われる） | cloudflared のログにホスト名がある |
| `train-archive.ana8labo.com` | 要確認 | `access-analyzer` の手順に名前がある |
| `ana8labo.com`、`www` | 未定 | creative-director に割り当てるかを含めて保留 |

- `kabu` の行き先 `web` は、STOCK の compose が `sharednet` に付けたエイリアスである
- Terraform の定義（`terraform/tunnel.tf`）は古い。`chat` が 8000 のままで、`tradereflect` と `bus` が無い。
  `terraform apply` は、定義を直すまで使わない

## 足す・変えるときの手順
1. [[shared/docker]] の「公開ポート」の表で、ポートの空きを確かめる
2. 行き先のコンテナを `sharednet` に入れ、名前の衝突を避けるエイリアスを付ける
3. Zero Trust のダッシュボードで、トンネル `ana8labo-tunnel` の Public Hostname にホスト名と行き先を足す（DNS の記録は自動で付く）
4. `sharednet` 上の使い捨てコンテナなどから、行き先に届くかを確かめる
5. このノートの表を更新する。分析の対象にするなら、`access-analyzer` に渡すホスト名にも足す

## トークンと失効
- `TUNNEL_TOKEN` が漏れたときは、ダッシュボードでトークンを再発行し、`.env` を直して cloudflared を作り直す
- ngrok の authtoken が、`G:` の `git\ngrok\ngrok.yml` に平文で残っている。
  ngrok のコンテナは止まっているので、トークンを失効させ、ファイルを消す（岡本が行う）
- Cloudflare の API トークンを発行するときは、必要なゾーンと権限だけに絞る

## 未決事項
- 全ホスト名の一覧を、ダッシュボードで照合する（上の表の「要確認」を埋める）
- Terraform を使い続けるか。使うなら、定義を直して `import` を終える。使わないなら `terraform/` を整理する
- `ana8labo.com` と `www` の行き先
- Cloudflare の分析を 14 日間で見られるかは、`access-analyzer` の手順で確かめていない
